//		-------------------Advection with Operator split and Dilatation(with truncation-------------------------//
//		--for heart--
//		x_centre=0.5; 	y_centre=0.32;   R=0.17;
//
//		--for Torsten Stillke's Flower--
//		L=2.0; H=2.0; R=0.0; with change in R you can find wiggles
//
//		_______________________________________________________________________________________________________//
#include<stdio.h>
#include<math.h>
#include"functions.h"
double mass_i,mass_f;
main()
{
//		--------------------------------domain and essentials--------------------------------------//
L=1.0;
H=1.0;
nx=64;
ny=64;
dx=L/nx;
dy=H/ny;
x_centre=L/2.0;
y_centre=0.75;
R=0.15;
dt=0.0078125;
//		----------------------------------PLIC Grid-----------------------------------------------//
xp[1]=0.0;
for(i=2;i<=nx+1;i++)
	xp[i]=xp[i-1]+dx;
yp[1]=0.0;
for(j=2;j<=ny+1;j++)
	yp[j]=yp[j-1]+dy;
//		--------------------------------------FVM Grid--------------------------------------------//
x[1]=0.5*dx;
for(i=2;i<=nx;i++)
	x[i]=x[i-1]+dx;

y[1]=0.5*dy;
for(j=2;j<=ny;j++)
	y[j]=y[j-1]+dy;

//Known Velocity
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			u[i][j]=-pow(sin(M_PI*x[i]),2.0)*sin(2.0*M_PI*y[j]); //Single Vortex
			v[i][j]=pow(sin(M_PI*y[j]),2.0)*sin(2.0*M_PI*x[i]); //Single vortex
//			u[i][j]=0.250;//(1-x[i]); // Pichku test
//			v[i][j]=0.0;//(1.0-y[j]); // Pichku test
//        	u[i][j]=(1.0/8.0)*(8.0*x[i]-4.0); // Droplet test
//			v[i][j]=(1.0/8.0)*(-(8.0*y[j]-4.0)-4.0-1.0+pow(8.0*x[i]-4.0,2.0)+pow(8.0*x[i]-4.0,4.0));//(1.0-y[j]); // Droplet test
//        	u[i][j]=0.25*((4.0*x[i]-2.0)+pow((4.0*y[j]-2.0),3.0)); // Superman Flow 
//       		v[i][j]=-0.25*((4.0*y[j]-2.0)+pow((4.0*x[i]-2.0),3.0)); // Superman Flow
// 			u[i][j]=(sin(4.0*M_PI*x[i]+2.0*M_PI)*sin(4.0*M_PI*y[j]+2.0*M_PI)); //Deformation_test (Rider-kothe)
//			v[i][j]=(cos(4.0*M_PI*x[i]+2.0*M_PI)*cos(4.0*M_PI*y[j]+2.0*M_PI)); //Deformation_test (Rider-Kothe)
//			u[i][j]=0.0;
//			v[i][j]=0.0;
        }
	}
//Vel boundary conditions
for(i=1;i<=nx;i++)
	{
//		v[i][0]=1.0;
//		v[i][ny+1]=0.0;
	}
for(j=1;j<=ny;j++)
	{
//		u[0][j]=1.0;
//		u[nx+1][j]=0.0;
	}
//		-------------------------------------Patching-intializing---------------------------------//
float xt,yt,dmx,dmy;
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			count=0;
			cv();
			for(p=1;p<=4;p++)
				{
				//---------------------------Heart------------------------------------------------------------------
//				pow(xv[p]-x_centre,2.0)+pow(5.0*(yv[p]-y_centre)/4.0-sqrt(fabs(xv[p]-x_centre)),2)-R<=0.0?count++:0;
				//---------------------------Circle-----------------------------------------------------------------
				pow(xv[p]-x_centre,2.0)+pow(yv[p]-y_centre,2.0)-R*R<=0.0?count++:0;
				//---------------------------Square(rotated)--------------------------------------------------------
//				fabs(xv[p]-x_centre)+fabs(yv[p]-y_centre)-R<=0.0?count++:0;
				//-----------------------Egg-Peanut-----------------------------------------------------------------
//				(pow(xv[p]-x_centre-1,2.0)+pow(yv[p]-y_centre,2.0))*(pow(xv[p]+x_centre-1,2.0)+pow(yv[p]-y_centre,2.0))-R<=0.0?count++:0;
				//-----------------------Torsten Sillke's flower----------------------------------------------------
//				pow((pow((xv[p]-x_centre),2.0)+pow((yv[p]-y_centre),2.0)),3.0)-4.0*(pow((xv[p]-x_centre),2.0))*pow((yv[p]-y_centre),2.0)-R<=0.0?count++:0;
				}
				if(count==4)
				phi[i][j]=1.0;
				else if(count==0)
				phi[i][j]=0.0;
			else
			{
				int mx=300,my=300;
				dmx=dx/mx;
				dmy=dy/my;
				count=0;
					for(p=1;p<=mx;p++)
						{
						for(q=1;q<=my;q++)
							{
							xt=xv[1]+(p-0.5)*dmx;
							yt=yv[1]+(q-0.5)*dmy;

					//---------------------------Heart------------------------------------------------------------------
//					pow(xt-x_centre,2.0)+pow(5.0*(yt-y_centre)/4.0-sqrt(fabs(xt-x_centre)),2)-R<=0.0?count++:0;
					//---------------------------------Circle-----------------------------------------------------
					pow(xt-x_centre,2.0)+pow(yt-y_centre,2.0)-R*R<=0.0?count++:0;
					//---------------------------Square(rotated)--------------------------------------------------------
//					fabs(xt-x_centre)+fabs(yt-y_centre)-R<=0.0?count++:0;
					//-----------------------Egg-Peanut-----------------------------------------------------------------
//					(pow(xt-x_centre-1,2.0)+pow(yt-y_centre,2.0))*(pow(xt+x_centre-1,2.0)+pow(yt-y_centre,2.0))-R<=0.0?count++:0;
					//-----------------------Torsten Sillke's flower----------------------------------------------------
//					pow((pow((xt-x_centre),2.0)+pow((yt-y_centre),2.0)),3.0)-4.0*(pow((xt-x_centre),2.0))*pow((yt-y_centre),2.0)-R<=0.0?count++:0;
					 		}
						}
				phi[i][j]=(count*1.0)/(mx*my); //total vol. fraction in cell [i,j]=No.of cells inside/total cells in cell [i,j]

			}
		}
	}

FILE *f3;
f3=fopen("Patch0.dat","w");
fprintf(f3,"\nVARIABLES=""X"",""Y"",""phi"",""u-vel"",""v-vel"" \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx,ny);
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			fprintf(f3,"\t%f\t%f\t%f\t%f\t%f\n",x[i],y[j],phi[i][j],u[i][j],v[i][j]);

		}
	//	fprintf(f1,"\n");
	}
fclose(f3);

mass_i=0.0;
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			mass_i=mass_i+phi[i][j]*dx*dy;
		}
	}
tc=0;
rcnst_count=0;
do
{
FILE *f2;
//sprintf (string, "state_%d.dat",tc);
f2=fopen("rcnst.dat","w");
//fprintf(f2,"\n\nVARIABLES=""X"",""Y"",""phi""\n\nI=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx,ny);
//Periodic Boundary conditions
/*	for(i=1;i<=nx;i++)
		{
		phi[i][0]=phi[i][ny];
		v[i][ny+1]=v[i][1];
	//	v[i][0]=v[i][ny];
	//	u[i][ny+1]=-u[i][ny];
		}
	for(i=1;i<=nx;i++)
		phi[i][ny+1]=phi[i][1];

	for(j=1;j<=ny;j++)
		{
		phi[0][j]=phi[nx][j];
	//	u[0][j]=2.0-u[1][j];
	//	u[nx+1][j]=-u[nx][j];
		}
	for(j=1;j<=ny;j++)
		phi[nx+1][j]=phi[1][j];
*/
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			//Face velocities
			fvel();

			if(phi[i][j]<=(1.0+eps) && phi[i][j]>=(1.0-eps))//pure water
				{
					pure_water();
				}
			else if (phi[i][j]>eps && phi[i][j]<(1.0-eps))//mixed cells
				{
//		--------------------------------------Reconstruction----------------------------------------------
					rcnst();
				
					fprintf(f2,"%f\t%f\n%f\t%f\n\n",x1_int[i],y1_int[j],x2_int[i],y2_int[j]);
//		-------------------------------------Flux Calculation----------------------------------
					advect();
				}//else-if for interface detection closure
			else//pure air
				{
					Fr[i][j]=0.0;
					Fl[i][j]=0.0;
					Ft[i][j]=0.0;
					Fb[i][j]=0.0;
				}
		}//For loop closure
	}//For loop closure
rcnst_count++;
//		-------------------------------------X-advection--------------------------------------------------
double sumx=0.0;
for (i=1;i<=nx;i++)
	{
	for (j=1;j<=ny;j++)
		{
				//Face velocities
				fvel();

				//periodic BC in fluxes
			/*	Fr[0][j]=Fr[nx][j];
				Ft[i][0]=Ft[i][ny];
				Fb[i][ny+1]=Fb[i][1];
				Fl[nx+1][j]=Fl[1][j];
			*///	printf("beta=%f\n",beta[i][j]);
//			phi_t[i][j]=phi[i][j]+(1.0/(dx*dy))*(-Fl[i][j]-Fr[i][j]+Fr[i-1][j]+Fl[i+1][j]); // w/o Dilatation
			phi_t[i][j]=(phi[i][j]+(1.0/(dx*dy))*(-Fl[i][j]-Fr[i][j]+Fr[i-1][j]+Fl[i+1][j]))/(1.0-(ue-uw)*dt/dx); // with Dilatation

				//Truncation of Overshoot and Undershoot (reco by Shashwat sir)
				if(phi_t[i][j]>(1+eps1)) // Overshoot
					phi_t[i][j]=1.0;
				else if(phi_t[i][j]<-eps1) //Undershoot
					phi_t[i][j]=0.0;

				phi[i][j]=phi_t[i][j];
				sumx=sumx+phi[i][j]*dx*dy;
		//		fprintf(f2,"%f\t%f\n%f\n",x[i],y[j],phi[i][j]);
		}
	}

for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			//Face velocities
			fvel();

			if(phi[i][j]<=(1.0+eps) && phi[i][j]>=(1.0-eps))//pure water
				{
					pure_water();
				}
			else if (phi[i][j]>eps && phi[i][j]<(1.0-eps))//mixed cells
				{
//		--------------------------------------Reconstruction----------------------------------------------
					rcnst();
		
				//	fprintf(f2,"%f\t%f\n%f\t%f\n\n",x1_int[i],y1_int[j],x2_int[i],y2_int[j]);
//		--------------------------------------Flux Calculations-------------------------------------------
					advect();
				}//else-if for interface detection closure
			else//pure air
				{
					Fr[i][j]=0.0;
					Fl[i][j]=0.0;
					Ft[i][j]=0.0;
					Fb[i][j]=0.0;
				}
		}//For loop closure
	}//For loop closure
rcnst_count++;
double sumy=0.0;
//		---------------------------------------Y-advection-----------------------------------------------
for (i=1;i<=nx;i++)
	{
	for (j=1;j<=ny;j++)
		{
				//Face velocities
				fvel();

				//periodic BC in fluxes
		/*		Fr[0][j]=Fr[nx][j];
				Ft[i][0]=Ft[i][ny];
				Fb[i][ny+1]=Fb[i][1];
				Fl[nx+1][j]=Fl[1][j];
*/
//			phinew[i][j]=phi_t[i][j]+(1.0/(dx*dy))*(-Fb[i][j]-Ft[i][j]+Fb[i][j+1]+Ft[i][j-1]); // w/o Dilatation
			phinew[i][j]=phi_t[i][j]*(1.0+(vn-vs)*dt/dy)+(1.0/(dx*dy))*(-Fb[i][j]-Ft[i][j]+Fb[i][j+1]+Ft[i][j-1]); // with Dilatation

				//Truncation of overshoot and undershoot (reco by Shashwat sir)
				if(phinew[i][j]>(1+eps1)) //Overshoot
					phinew[i][j]=1.0;
				else if(phinew[i][j]<-eps1) //Undershoot
					phinew[i][j]=0.0;

				phi[i][j]=phinew[i][j];
				sumy=sumy+phi[i][j]*dx*dy;
		//		fprintf(f2,"%f\t%f\n%f\n",x[i],y[j],phi[i][j]);
		}
	}
printf("\nMass Loss(percent)=  %.10f \t Time= %f \t Reconstruction happens %d times\n",fabs(sumx-sumy)*100,time,rcnst_count);
tc=tc+1;
time=tc*dt;
fclose(f2);
}while(time<=1.0);

mass_f=0.0;
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			mass_f=mass_f+phi[i][j]*dx*dy;
		}
	}
printf("Mass Loss(%%)=%.15f\n",fabs(mass_i-mass_f)*100);
//		-------------------------------------------File Writing-----------------------------------------//

FILE *f1;
f1=fopen("Plic_grid1.dat","w");
//fprintf(f1,"\nVARIABLES=""X"",""Y"", \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx+1,ny+1);
for(i=1;i<=nx+1;i++)
	{
	for(j=1;j<=ny+1;j++)
		{
			fprintf(f1,"\t%f\t%f\n",xp[i],yp[j]);

		}
		fprintf(f1,"\n");
	}
fclose(f1);

f1=fopen("Plic_grid2.dat","w");
//fprintf(f1,"\nVARIABLES=""X"",""Y"", \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx+1,ny+1);
for(j=1;j<=ny+1;j++)
	{
	for(i=1;i<=nx+1;i++)
		{
			fprintf(f1,"\t%f\t%f\n",xp[i],yp[j]);
		}
		fprintf(f1,"\n");
	}
fclose(f1);
/*
FILE *f3;
f3=fopen("Patch.dat","w");
fprintf(f3,"\nVARIABLES=""X"",""Y"",""phi"",""u-vel"",""v-vel"" \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx,ny);
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			fprintf(f3,"\t%f\t%f\t%f\t%f\t%f\n",x[i],y[j],phi[i][j],u[i][j],v[i][j]);

		}
	//	fprintf(f1,"\n");
	}
fclose(f3);

*/}
