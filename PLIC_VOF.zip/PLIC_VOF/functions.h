int i,j,nx,ny,count,p,q,a,tc;
float x[500],y[500],dx,dy,L,H,x_centre,y_centre,phi[500][500],xv[5],yv[5],xb[500],yb[500],R;
float nr_x[500][500],nr_y[500][500],beta[500][500],x1_int[500],y1_int[500],x2_int[500],y2_int[500];
float sl[500][500],sb[500][500],sr[500][500],st[500][500],nr_x0[500][500],nr_y0[500][500];
float xp[500],yp[500],alp[500][500];
double eps=1.0*pow(10,-12);// According to Rider-Kothe
double time,dt,vel,s1,l1,gr,s2,l2,flx,Fr[500][500]={0.0},Fl[500][500]={0.0},Fb[500][500]={0.0},Ft[500][500]={0.0};
double phi_t[500][500],phinew[500][500],pl=0.0,pr=0.0,pb=0.0,pt=0.0,u,v,c;
char string[100];

//		--------------------------------------declaring vertices--------------------------------------//
void cv()			//				Cell Vertices
				// 		4(top left)		3(top right)
 				//		1(bottom left)	 	2(bottom right)  
{
	xv[1]=xp[i];		yv[1]=yp[j];
	xv[2]=xp[i+1];		yv[2]=yp[j];
	xv[3]=xp[i+1];		yv[3]=yp[j+1];
	xv[4]=xp[i];		yv[4]=yp[j+1];
}

//		-------------------------------Reconstruction-------------------------------------------------//
void rcnst()
	{
// 		-----------------------------------Normals_and_angle_with_horizontal---------------------------
				nr_x[i][j]=(1/(8.0*dx))*(phi[i+1][j+1]+2.0*phi[i+1][j]+phi[i+1][j-1]-phi[i-1][j+1]-2.0*phi[i-1][j]-phi[i-1][j-1]);
				nr_y[i][j]=(1/(8.0*dy))*(phi[i+1][j+1]+2.0*phi[i][j+1]+phi[i-1][j+1]-phi[i+1][j-1]-2.0*phi[i][j-1]-phi[i-1][j-1]);
//		---------------------------------------Angle of interface with the horizontal---------------------
				alp[i][j]=(atan(-nr_x[i][j]/nr_y[i][j])); 	//radians
				beta[i][j]=atan((dx/dy)*tan(alp[i][j])); 	//radians
//		---------------------------------------When beta is -ve-------------------------------------------
				if((nr_x[i][j]>0.0 && nr_y[i][j]>0.0) ||(nr_x[i][j]<0.0 && nr_y[i][j]<0.0))
					beta[i][j]=M_PI/2.0+(beta[i][j]);

//		-------------------Case Identification(Rudman Algorithm)feat. Shashwat_sir-----------------------//
	if(beta[i][j]<(M_PI/4.0))
		{
			if (phi[i][j]<=0.5*tan(beta[i][j]))
//		----------------------------------CASE I---------------------------------
				{
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					sr[i][j]=sqrt(phi[i][j]*2.0*((tan(beta[i][j]))));
					sb[i][j]=sqrt(phi[i][j]*(1.0/tan(beta[i][j]))*2.0);
					sl[i][j]=0.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
										
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
				//	printf("case I \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					sl[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					sb[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);
					sr[i][j]=0.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
				//	printf("case I \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					st[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					sl[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);	
					sr[i][j]=0.0;
					sb[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
				//	printf("case I \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sr[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					st[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);
					sb[i][j]=0.0;
					sl[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
				//	printf("case I \t q1 %d_%d",i,j);
					}					
			
				}
			else if(phi[i][j]<=(1.0-0.5*tan(beta[i][j])))	
				{
//		----------------------------------CASE II--------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					sr[i][j]=phi[i][j]+0.5*(tan(beta[i][j]));
					sl[i][j]=phi[i][j]-0.5*(tan(beta[i][j]));
					sb[i][j]=1.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx;
					y1_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
										
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
				//	printf("case II \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					st[i][j]=phi[i][j]-0.5*(tan(beta[i][j]));
					sb[i][j]=phi[i][j]+0.5*(tan(beta[i][j]));
					sr[i][j]=0.0;
					sl[i][j]=1.0;
					x1_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
				//	printf("case II \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					sr[i][j]=phi[i][j]-0.5*(tan(beta[i][j]));
					sl[i][j]=phi[i][j]+0.5*(tan(beta[i][j]));
					sb[i][j]=0.0;
					st[i][j]=1.0;
					
					x1_int[i]=x[i]-0.5*dx;
					y1_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
				//	printf("case II \t q2 %d_%d",i,j);	
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					st[i][j]=phi[i][j]+0.5*(tan(beta[i][j]));
					sb[i][j]=phi[i][j]-0.5*(tan(beta[i][j]));
					sr[i][j]=1.0;
					sl[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y2_int[j]=y[j]-0.5*dy;
				//	printf("case II \t q1 %d_%d",i,j);	
					}
				}
			else 
				{
//		---------------------------------CASE IV---------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					st[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sl[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sr[i][j]=1.0;
					sb[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
				//	printf("case IV \t q4 %d_%d",i,j);
					}	
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					sr[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					st[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sl[i][j]=1.0;
					sb[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx;
					y1_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
					
					x2_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
				//	printf("case IV \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					sb[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sr[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					st[i][j]=1.0;
					sl[i][j]=1.0; 
					x1_int[i]=x[i]+0.5*dx;
					y1_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
					
					x2_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y2_int[j]=y[j]-0.5*dy;
				//	printf("case IV \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sl[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sb[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sr[i][j]=1.0;
					st[i][j]=1.0;					
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
				//	printf("case IV \t q1 %d_%d",i,j);
					}
				}
		}
	else 
		{
			if(phi[i][j]<=0.5*(1.0/(tan(beta[i][j]))))
//		-------------------------------CASE I------------------------------------
				{
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					sr[i][j]=sqrt(phi[i][j]*2.0*((tan(beta[i][j]))));
					sb[i][j]=sqrt(phi[i][j]*(1.0/tan(beta[i][j]))*2.0);
					sl[i][j]=0.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
										
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
				//	printf("case I \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					sl[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					sb[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);
					sr[i][j]=0.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
				//	printf("case I \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					st[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					sl[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);	
					sr[i][j]=0.0;
					sb[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
				//	printf("case I \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sr[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					st[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);
					sb[i][j]=0.0;
					sl[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
				//	printf("case I \t q1 %d_%d",i,j);
					}					
				}
			else if (phi[i][j]<=(1.0-0.5*(1.0/(tan(beta[i][j])))))
				{
//		----------------------------CASE III-------------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					st[i][j]=phi[i][j]-0.5*(1.0/(tan(beta[i][j])));
					sb[i][j]=phi[i][j]+0.5*(1.0/(tan(beta[i][j])));
					sl[i][j]=0.0;
					sr[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
				//	printf("case III \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{	
//					third quadrant
			 		sl[i][j]=phi[i][j]+0.5*(1.0/(tan(beta[i][j])));
					sr[i][j]=phi[i][j]-0.5*(1.0/(tan(beta[i][j])));
					st[i][j]=0.0;
					sb[i][j]=1.0;
					
					x1_int[i]=x[i]-0.5*dx;
					y1_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
				//	printf("case III \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					st[i][j]=phi[i][j]+0.5*(1.0/(tan(beta[i][j])));
					sb[i][j]=phi[i][j]-0.5*(1.0/(tan(beta[i][j])));
					sl[i][j]=1.0;
					sr[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
				//	printf("case III \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sl[i][j]=phi[i][j]-0.5*(1.0/(tan(beta[i][j])));
					sr[i][j]=phi[i][j]+0.5*(1.0/(tan(beta[i][j])));
					sb[i][j]=0.0;
					st[i][j]=1.0;
					x1_int[i]=x[i]-0.5*dx;
					y1_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
				//	printf("case III \t q1 %d_%d",i,j);
					}
				}
			else 	
				{
//		----------------------------CASE IV--------------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					st[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sl[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sr[i][j]=1.0;
					sb[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
				//	printf("case IV \t q4 %d_%d",i,j);
					}	
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					sr[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					st[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sl[i][j]=1.0;
					sb[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx;
					y1_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
					
					x2_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
				//	printf("case IV \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					sb[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sr[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					st[i][j]=1.0;
					sl[i][j]=1.0; 
					x1_int[i]=x[i]+0.5*dx;
					y1_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
					
					x2_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y2_int[j]=y[j]-0.5*dy;
				//	printf("case IV \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sl[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sb[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sr[i][j]=1.0;
					st[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
				//	printf("case IV \t q1 %d_%d",i,j);
					}
				}
			}			
//		----------------------------------zero normals calculations----------------------------------
	if(nr_x[i][j]==0.0 && nr_y[i][j]>0.0)
		{
			sr[i][j]=phi[i][j];
			sl[i][j]=sr[i][j];
			st[i][j]=1.0;
			sb[i][j]=0.0;
			x1_int[i]=x[i]+0.5*dx;
			y1_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
			
			x2_int[i]=x[i]-0.5*dx;
			y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
		//	printf("nx=0 ny+ \t  %d_%d",i,j);	
		}else if(nr_x[i][j]==0.0 && nr_y[i][j]<0.0)
			{
				sr[i][j]=phi[i][j];
				sl[i][j]=sr[i][j];
				st[i][j]=0.0;
				sb[i][j]=1.0;
				x1_int[i]=x[i]+0.5*dx;
				y1_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
				
				x2_int[i]=x[i]-0.5*dx;
				y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;	
		//		printf("nx=0 ny- \t  %d_%d",i,j);
			}else if(nr_y[i][j]==0.0 && nr_x[i][j]<0.0)
				{
					st[i][j]=phi[i][j];
					sb[i][j]=st[i][j];
					sr[i][j]=0.0;
					sl[i][j]=1.0;
					x1_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y2_int[j]=y[j]-0.5*dy;	
		//			printf("ny=0 nx- \t  %d_%d",i,j);
				}else if(nr_y[i][j]==0.0 && nr_x[i][j]>0.0)
					{
						st[i][j]=phi[i][j];
						sb[i][j]=st[i][j];
						sr[i][j]=1.0;
						sl[i][j]=0.0;
						x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
						y1_int[j]=y[j]+0.5*dy;						
						x2_int[i]=x[i]+0.5*dx-sb[i][j]*dy;
						y2_int[j]=y[j]-0.5*dy;	
		//				printf("ny=0 nx+ \t  %d_%d",i,j);
					}
							
		}
//		-------------------------------Functions_for_fluxes-------------------------------------------//
//Case I
void xorig1r()//right
	{
		if(fabs(vel)*dt>=s2*l2)
			flx=phi[i][j]*dx*dy;
		else
			flx=0.5*fabs(vel)*dt*(2.0-fabs(vel)*dt/(s2*l2))*s1*l1;	
	}
void yorig1t()//top
	{
		if(fabs(vel)*dt<=(1.0-s1)*l1)
			flx=0.0;
		else
			flx=0.5*pow(fabs(vel)*dt-(1.0-s1)*l1,2.0)*gr;		
	}
void xorig1l()//left
	{
		if(fabs(vel)*dt<=(1.0-s2)*l2)
			flx=0.0;
		else
			flx=0.5*pow((fabs(vel)*dt-(1.0-s2)*l2),2.0)*gr;		
	}
void yorig1b()//bottom
	{
		if(fabs(vel)*dt>=s1*l1)
			flx=phi[i][j]*dx*dy;
		else
			flx=0.5*fabs(vel)*dt*(2.0-fabs(vel)*dt/(s1*l1))*s2*l2;	
	}
//Case II
void xorig2r()//right
	{
		flx=fabs(vel)*dt*(s1*l1-0.5*fabs(vel)*dt*gr);
	}
void yorig2t()
	{
		if(fabs(vel)*dt<=(1.0-s1)*l1)
			flx=0.0;
		else if(fabs(vel)*dt<=(1.0-s2)*l1)
			flx=0.5*pow(fabs(vel)*dt-(1.0-s1)*l1,2.0)*gr;
		else 
			flx=fabs(vel)*dt*l2-(1.0-phi[i][j])*dx*dy;		
	}
void xorig2l()
	{
		flx=fabs(vel)*dt*(s2*l1+0.5*fabs(vel)*dt*gr);	
	}
void yorig2b()
	{
		if(fabs(vel)*dt<=s2*l1)
			flx=fabs(vel)*dt*l2;
		else if(fabs(vel)*dt<=s1*l1)
			flx=fabs(vel)*dt*l2-0.5*pow(fabs(vel)*dt-s2*l1,2.0)*gr;
		else
			flx=phi[i][j]*dx*dy;		
	}
//Case III
void xorig3r()
	{
		if(fabs(vel)*dt<=s2*l1)
			flx=fabs(vel)*dt*l2;
		else if(fabs(vel)*dt<=s1*l1)
			flx=fabs(vel)*dt*l2-0.5*pow(fabs(vel)*dt-s2*l1,2.0)*gr;
		else 
			flx=phi[i][j]*dx*dy;			
	}
void yorig3t()
	{
		flx=fabs(vel)*dt*(s2*l1+0.5*fabs(vel)*dt*gr);	
	}
void xorig3l()
	{
		if(fabs(vel)*dt<=(1.0-s1)*l1)
			flx=0.0;
		else if(fabs(vel)*dt<=(1.0-s2)*l1)
			flx=0.5*pow((fabs(vel)*dt-(1.0-s1)*l1),2.0)*gr;
		else
			flx=fabs(vel)*dt*l2-(1.0-phi[i][j])*dx*dy;		
	}
void yorig3b()
	{
		flx=fabs(vel)*dt*(s1*l1-0.5*fabs(vel)*dt*gr);
	}
//Case IV
void xorig4r()
	{
		if(fabs(vel)*dt<=s2*l2)
			flx=fabs(vel)*dt*l1;
		else 
		flx=fabs(vel)*dt*l1-0.5*pow((fabs(vel)*dt-s2*l2),2.0)*gr;	
	}
void yorig4t()
	{
		if(fabs(vel)*dt>=(1.0-s1)*l1)
			flx=fabs(vel)*dt*l2-(1.0-phi[i][j])*dx*dy;
		else
			flx=fabs(vel)*dt*(s2*l2+0.5*fabs(vel)*dt*gr);	
	}
void xorig4l()
	{
		if(fabs(vel)*dt>=(1.0-s2)*l2)
			flx=fabs(vel)*dt*l1-(1.0-phi[i][j])*dx*dy;
		else
			flx=fabs(vel)*dt*(s1*l1+0.5*fabs(vel)*dt*gr);	
	}
void yorig4b()
	{
		if(fabs(vel)*dt<=s1*l1)
			flx=fabs(vel)*dt*l2;
		else
			flx=fabs(vel)*dt*l2-0.5*gr*pow(fabs(vel)*dt-s1*l1,2.0);	
	}
	
//		--------------------------------------Zero normals advection--------------------------------------
void nx0nypt()
	{
		if(fabs(vel)*dt<sr[i][j]*dy)
			flx=fabs(vel)*dt*dx;
		else
			flx=sr[i][j]*dy*dx;
	}
void nx0nypb()
	{
		if(fabs(vel)*dt<=(1.0-sr[i][j])*dy)
			flx=0.0;
		else
			flx=(fabs(vel)*dt-(1.0-sr[i][j])*dy)*dx;	
	}
void nx0nypr()
	{
			flx=fabs(vel)*dt*sr[i][j]*dy;
	}	
void nx0nypl()
	{
			flx=fabs(vel)*dt*sr[i][j]*dy;	
	}	
	
void nx0nynt()
	{
		if(fabs(vel)*dt<=(1.0-sr[i][j])*dy)
			flx=0.0;
		else
			flx=(fabs(vel)*dt-(1.0-sr[i][j])*dy)*dx;		
	}
void nx0nynb()
	{
		if(fabs(vel)*dt<(sr[i][j])*dy)
			flx=fabs(vel)*dt*dx;
		else
			flx=sr[i][j]*dy*dx;	
	}	
void nx0nynr()
	{
		flx=fabs(vel)*dt*sr[i][j]*dy;
	}
void nx0nynl()
	{
		flx=fabs(vel)*dt*sr[i][j]*dy;		
	}	
void ny0nxnr()
	{
		if(fabs(vel)*dt<(1.0-sb[i][j])*dx)
			flx=0.0;
		else
			flx=(fabs(vel)*dt-(1.0-sb[i][j])*dx)*dy;
	}	
void ny0nxnl()
	{
		if(fabs(vel)*dt<(sb[i][j])*dx)
			flx=fabs(vel)*dt*dy;
		else
			flx=sb[i][j]*dx*dy;
	}	
void ny0nxnt()
	{
		flx=fabs(vel)*dt*sb[i][j]*dx;		
	}	
void ny0nxnb()
	{
		flx=fabs(vel)*dt*sb[i][j]*dx;		
	}						
void ny0nxpr()
	{
		if(fabs(vel)*dt<sb[i][j]*dx)
			flx=fabs(vel)*dt*dy;
		else
			flx=sb[i][j]*dx*dy;
	}	
void ny0nxpl()
	{
		if(fabs(vel)*dt<=(1.0-sb[i][j])*dx)
			flx=0.0;
		else
			flx=(fabs(vel)*dt-(1.0-sb[i][j])*dx)*dy;
	}	
void ny0nxpt()
	{
		flx=fabs(vel)*dt*sb[i][j]*dx;	
	}	
void ny0nxpb()
	{
		flx=fabs(vel)*dt*sb[i][j]*dx;		
	}						

//________________________________________________________________Advection_churan___________________________________________		
void advect()
	{

// 		
//		-------------------Case Identification(Rudman Algorithm)feat. Shashwat_sir-----------------------//
	if(beta[i][j]<(M_PI/4.0))
		{
			if (phi[i][j]<=0.5*tan(beta[i][j]))
//		----------------------------------CASE I---------------------------------
				{
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//				fourth quadrant
				s1=sr[i][j];
				l1=dy;
				s2=sb[i][j];
				l2=dx;
				
				//right	
					if(u>0.0)
					{	
					vel=u;		
					xorig1r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;	
				//left
					if(u<0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig1l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
				//top
					if(v>0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig1t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(v<0.0)
					{
					vel=v;
					yorig1b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//printf("case I \t q4 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
				{
//				third quadrant
					s1=sb[i][j];
					l1=dx;
					s2=sl[i][j];
					l2=dy;
				//right
					if(u>0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig1t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(u<0.0)
					{
					vel=u;
					yorig1b();
					Fl[i][j]=flx;
					}else 
					Fl[i][j]=0.0;
				//top
					if(v>0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig1l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(v<0.0)
					{
					vel=v;
					xorig1r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//printf("case I \t q3 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
				}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
				s1=sl[i][j];
				l1=dy;
				s2=st[i][j];
				l2=dx;
				//right
					if(u>0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig1l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(u<0.0)
					{
					vel=u;
					xorig1r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;	
				//top
					if(v>0.0)
					{
					vel=v;
					yorig1b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;	
				//bottom
					if(v<0.0)
					{
					vel=v;
					gr=(1.0/tan(alp[i][j]));
					yorig1t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
						
					//printf("case I \t q2 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
				s1=st[i][j];
				l1=dx;
				l2=dy;
				s2=sr[i][j];
				//right
					if(u>0.0)
					{
					vel=u;
					yorig1b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(u<0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig1t();
					Fl[i][j]=flx;
					}else 
					Fl[i][j]=0.0;
				//top
					if(v>0.0)
					{
					vel=v;
					xorig1r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(v<0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig1l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case I \t q1 %d_%d",i,j);
					}					
			
				}
			else if(phi[i][j]<=(1.0-0.5*tan(beta[i][j])))	
				{
//		----------------------------------CASE II--------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					s1=sr[i][j];
					s2=sl[i][j];
					l1=dy;
					l2=dx;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig2r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					
					//left
					if(u<0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig2l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig2t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig2b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case II \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					s1=sb[i][j];
					s2=st[i][j];
					l1=dx;
					l2=dy;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig2t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig2b();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					
					//top
					if(v>0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig2l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig2r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
					
				//	printf("case II \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					s1=sl[i][j];
					s2=sr[i][j];
					l1=dy;
					l2=dx;
					//right
					if(u>0.0)
					{		
					vel=u;	
					gr=tan(alp[i][j]);
					xorig2l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig2r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);		
					yorig2b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig2t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;	
				//	printf("case II \t q2 %d_%d",i,j);	
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					s1=st[i][j];
					s2=sb[i][j];
					l1=dx;
					l2=dy;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig2b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig2t();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig2r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig2l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;	
				//	printf("case II \t q1 %d_%d",i,j);	
					}
				}
			else 
				{
//		---------------------------------CASE IV---------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					s1=sl[i][j];
					s2=st[i][j];
					l1=dy;
					l2=dx;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig4r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig4l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig4t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig4b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q4 %d_%d",i,j);
				}	
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					s1=st[i][j];
					l1=dx;
					s2=sr[i][j];
					l2=dy;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig4t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig4b();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;	
				//	printf("case IV \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					s1=sr[i][j];
					l1=dy;
					s2=sb[i][j];
					l2=dx;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig4l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig4r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig4b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig4t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					s1=sb[i][j];
					l1=dx;
					s2=sl[i][j];
					l2=dy;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig4b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig4t();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;	
					//top
					if(v>0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q1 %d_%d",i,j);
					}
				}
		}
	else 
		{
			if(phi[i][j]<=0.5*(1.0/(tan(beta[i][j]))))
//		-------------------------------CASE I------------------------------------
				{
			if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//				fourth quadrant
				s1=sr[i][j];
				l1=dy;
				s2=sb[i][j];
				l2=dx;
				
				//right	
					if(u>0.0)
					{	
					vel=u;		
					xorig1r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;	
				
				//left
					if(u<0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig1l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
				
				//top
					if(v>0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig1t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(v<0.0)
					{
					vel=v;
					yorig1b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//printf("case I \t q4 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
				{
//				third quadrant
					s1=sb[i][j];
					l1=dx;
					s2=sl[i][j];
					l2=dy;
				//right
					if(u>0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig1t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(u<0.0)
					{
					vel=u;
					yorig1b();
					Fl[i][j]=flx;
					}else 
					Fl[i][j]=0.0;
				//top
					if(v>0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig1l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(v<0.0)
					{
					vel=v;
					xorig1r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//printf("case I \t q3 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
				}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
				s1=sl[i][j];
				l1=dy;
				s2=st[i][j];
				l2=dx;
				//right
					if(u>0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig1l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(u<0.0)
					{
					vel=u;
					xorig1r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;	
				//top
					if(v>0.0)
					{
					vel=v;
					yorig1b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;	
				//bottom
					if(v<0.0)
					{
					vel=v;
					gr=(1.0/tan(alp[i][j]));
					yorig1t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
						
					//printf("case I \t q2 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
				s1=st[i][j];
				l1=dx;
				l2=dy;
				s2=sr[i][j];
				//right
					if(u>0.0)
					{
					vel=u;
					yorig1b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(u<0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig1t();
					Fl[i][j]=flx;
					}else 
					Fl[i][j]=0.0;
				//top
					if(v>0.0)
					{
					vel=v;
					xorig1r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(v<0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig1l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case I \t q1 %d_%d",i,j);
					}										
			}
			else if (phi[i][j]<=(1.0-0.5*(1.0/(tan(beta[i][j])))))
				{
//		----------------------------CASE III-------------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
				s1=sb[i][j];
				s2=st[i][j];
				l1=dx;
				l2=dy;
				//right
				if(u>0.0)
				{
				vel=u;
				gr=tan(alp[i][j]);
				xorig3r();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;
				//left
				if(u<0.0)
				{
				vel=u;
				gr=tan(alp[i][j]);
				xorig3l();
				Fl[i][j]=flx;
				}else
				Fl[i][j]=0.0;
				//top
				if(v>0.0)
				{
				vel=v;
				gr=1.0/tan(alp[i][j]);
				yorig3t();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(v<0.0)
				{
				vel=v;
				gr=1.0/tan(alp[i][j]);
				yorig3b();
				Fb[i][j]=flx;
				}else
				Fb[i][j]=0.0;
			//	printf("case III \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{	
//				third quadrant
				s1=sl[i][j];
				s2=sr[i][j];
				l1=dy;
				l2=dx;
				//right
				if(u>0.0)
				{
				vel=u;
				gr=fabs(tan(alp[i][j]));
				yorig3t();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;
				//left
				if(u<0.0)
				{
				vel=u;
				gr=fabs(tan(alp[i][j]));
				yorig3b();
				Fl[i][j]=flx;
				}else
				Fl[i][j]=0.0;
				//top
				if(v>0.0)
				{
				vel=v;
				gr=fabs(1.0/tan(alp[i][j]));
				xorig3l();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(v<0.0)
				{
				vel=v;
				gr=fabs(1.0/tan(alp[i][j]));
				xorig3r();
				Fb[i][j]=flx;	
				}else
				Fb[i][j]=0.0;
			//	printf("case III \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//				second quadrant
				s1=st[i][j];
				s2=sb[i][j];
				l1=dx;
				l2=dy;
				//right
				if(u>0.0)
				{
				vel=u;
				gr=tan(alp[i][j]);
				xorig3l();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;
				//left
				if(u<0.0)
				{
				vel=u;
				gr=tan(alp[i][j]);
				xorig3r();
				Fl[i][j]=flx;
				}else
				Fl[i][j]=0.0;
				//top
				if(v>0.0)
				{
				vel=v;
				gr=1.0/tan(alp[i][j]);
				yorig3b();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(v<0.0)
				{
				vel=v;
				gr=1.0/tan(alp[i][j]);
				yorig3t();
				Fb[i][j]=flx;
				}else
				Fb[i][j]=0.0;
				//	printf("case III \t q2 %d_%d",i,j);
				}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
				{
//				first quadrant
				s1=sr[i][j];
				s2=sl[i][j];
				l1=dy;
				l2=dx;
				//right
				if(u>0.0)
				{
				vel=u;
				gr=fabs(tan(alp[i][j]));
				yorig3b();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;	
				//left
				if(u<0.0)
				{
				vel=u;
				gr=fabs(tan(alp[i][j]));
				yorig3t();
				Fl[i][j]=flx;
				}else
				Fl[i][j]=0.0;
				//top
				if(v>0.0)
				{
				vel=v;
				gr=fabs(1.0/tan(alp[i][j]));
				xorig3r();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(v<0.0)
				{
				vel=v;
				gr=fabs(1.0/tan(alp[i][j]));
				xorig3l();
				Fb[i][j]=flx;	
				}else
				Fb[i][j]=0.0;	
			//	printf("case III \t q1 %d_%d",i,j);
					}
				}
			else 	
				{
//		----------------------------CASE IV--------------------------------------
		if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					s1=sl[i][j];
					s2=st[i][j];
					l1=dy;
					l2=dx;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig4r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig4l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig4t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig4b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q4 %d_%d",i,j);
					}	
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					s1=st[i][j];
					l1=dx;
					s2=sr[i][j];
					l2=dy;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig4t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig4b();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;	
				//	printf("case IV \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					s1=sr[i][j];
					l1=dy;
					s2=sb[i][j];
					l2=dx;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig4l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=tan(alp[i][j]);
					xorig4r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(v>0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig4b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=1.0/tan(alp[i][j]);
					yorig4t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					s1=sb[i][j];
					l1=dx;
					s2=sl[i][j];
					l2=dy;
					//right
					if(u>0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig4b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(u<0.0)
					{
					vel=u;
					gr=fabs(tan(alp[i][j]));
					yorig4t();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;	
					//top
					if(v>0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(v<0.0)
					{
					vel=v;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q1 %d_%d",i,j);
					}
				}
			}			
//		----------------------------------zero normals calculations----------------------------------
	if(nr_x[i][j]==0.0 && nr_y[i][j]>0.0)
		{
		//top
		if(v>0.0)
		{
		vel=v;
		nx0nypt();
		Ft[i][j]=flx;		
		}else
		Ft[i][j]=0.0;
		//bottom
		if(v<0.0)
		{
		vel=v;
		nx0nypb();
		Fb[i][j]=flx;
		}else
		Fb[i][j]=0.0;
		//right
		if(u>0.0)
		{
		vel=u;
		nx0nypr();
		Fr[i][j]=flx;
		}else
		Fr[i][j]=0.0;	
	
		//left
		if(u<0.0)
		{
		vel=u;
		nx0nypl();
		Fl[i][j]=flx;
		}else
		Fl[i][j]=0.0;
		//	printf("nx=0 ny+ \t  %d_%d",i,j);	
		}else if(nr_x[i][j]==0.0 && nr_y[i][j]<0.0)
			{
				//top
				if(v>0.0)
				{
				vel=v;
				nx0nynt();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(v<0.0)
				{
				vel=v;
				nx0nynb();
				Fb[i][j]=flx;	
				}else
				Fb[i][j]=0.0;
				//right
				if(u>0.0)
				{
				vel=u;
				nx0nynr();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;
				//left
				if(u<0.0)
				{
				vel=u;
				nx0nynl();
				Fl[i][j]=flx;	
				}else
				Fl[i][j]=0.0;	
		//		printf("nx=0 ny- \t  %d_%d",i,j);
			}else if(nr_y[i][j]==0.0 && nr_x[i][j]<0.0)
				{
						//right
						if(u>0.0)
						{
						vel=u;
						ny0nxnr();
						Fr[i][j]=flx;
						}else
						Fr[i][j]=0.0;	
						//left
						if(u<0.0)
						{
						vel=u;
						ny0nxnl();
						Fl[i][j]=flx;	
						}else
						Fl[i][j]=0.0;
						//top
						if(v>0.0)
						{
						vel=v;
						ny0nxnt();
						Ft[i][j]=flx;
						}else
						Ft[i][j]=0.0;	
						//bottom
						if(v<0.0)
						{
						vel=v;
						ny0nxnb();
						Fb[i][j]=flx;
						}else
						Fb[i][j]=0.0;						
		//			printf("ny=0 nx- \t  %d_%d",i,j);
				}else if(nr_y[i][j]==0.0 && nr_x[i][j]>0.0)
					{
						//right
						if(u>0.0)
						{
						vel=u;
						ny0nxpr();
						Fr[i][j]=flx;
						}else
						Fr[i][j]=0.0;
						//left
						if(u<0.0)
						{
						vel=u;
						ny0nxpl();
						Fl[i][j]=flx;
						}else
						Fl[i][j]=0.0;
						//top
						if(v>0.0)
						{
						vel=v;
						ny0nxpt();
						Ft[i][j]=flx;
						}else
						Ft[i][j]=0.0;				
						//bottom
						if(v<0.0)
						{
						vel=v;
						ny0nxpb();
						Fb[i][j]=flx;
						}else
						Fb[i][j]=0.0;						
		//				printf("ny=0 nx+ \t  %d_%d",i,j);
					}
					
	}


