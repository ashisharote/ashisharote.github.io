int i,j,nx,ny,nz,k,r,count,p,q,a,tc,rcnst_count,p1;
double x[350],y[350],z[300],dx,dy,dz,L,H,W,x_centre,y_centre,z_centre,xv[20],yv[20],zv[20],R;
double xp[350],yp[350],zp[300],alp[350][350];
double tim,dt,vel,s1,l1,gr,s2,l2,flx;
double c,ue,uw,vn,vs,wt,wb;
char string[300];
double phi[350][350][300],phi_t[350][350][300],v[350][350][300],u[350][350][300],w[350][350][300];
#define eps 1e-13// According to Rider-Kothe
#define eps1 1e-15
# define pi 3.14592653589793
//Redistribution
double phi_max,phi_min,phi_temp,max,min;
int I,s,m,n,ar,br,cr,dr,er,fr,forlorn,al,bl,cl,scheme;
double xnf,xnd,afsu;
double atfu1,atfu2,blend_h,ep;
//Redistribution Shaswat Sir's code
void redistribution()
{
	do
	{
		forlorn=0;
	for(i=1;i<=nx;i++)
			{
				for(j=1;j<=ny;j++)
				{
					for(k=1;k<=nz;k++)
					{
						if(phi_t[i][j][k]<-eps)//undershoot
							{
 								 I=1;
								do
								{
									min=10.0;
									for(s=i-I;s<=I+i;s++)
									{
										for(m=j-I;m<=j+I;m++)
										{
											for(n=k-I;n<=k+I;n++)
											{
												if((s==i&&m==j&&n==k)||(s<1)||(m<1)||(n<1)||(s>nx)||(m>ny)||(n>nz))
													continue;
												else
													{
														if(phi_t[s][m][n]<=min&&phi_t[s][m][n]!=0.0)
																{
																	min=phi_t[s][m][n];
																	al=s;
																	bl=m;
																	cl=n;
																}
													}
											}
										}
									}
												if(phi_t[al][bl][cl]==0.0)
													{
														I=I+1;
													}
												phi_temp=phi_t[al][bl][cl]+phi_t[i][j][k];
												phi_t[al][bl][cl]=fmax(phi_temp,0.0);
												phi_t[i][j][k]=fmin(phi_temp,0.0);
							}while(phi_t[i][j][k]<-eps);
						}else if (phi_t[i][j][k]>1.0+eps)//Overshoot
							{
								I=1;
										do
										{
											max=-10.0;
											for(s=i-I;s<=I+i;s++)
											{
												for(m=j-I;m<=j+I;m++)
												{
													for(n=k-I;n<=k+I;n++)
													{
														if((s==i&&m==j&&n==k)||(s<1)||(m<1)||(n<1)||(s>nx)||(m>ny)||(n>nz))
														continue;
														else
															{
																if(phi_t[s][m][n]>=max&&phi_t[s][m][n]!=1.0)
																	{
																		max=phi_t[s][m][n];
																		al=s;
																		bl=m;
																		cl=n;
																	}
															}
													}
												}
											}
											if(phi_t[al][bl][cl]==1.0)
											{
												I=I+1;
											}
											phi_temp=phi_t[al][bl][cl]+phi_t[i][j][k]-1.0;
											phi_t[al][bl][cl]=fmin(phi_temp,1.0);
											phi_t[i][j][k]=fmax(phi_temp,1.0);


										}while(phi_t[i][j][k]>1.0+eps);
							}else
								continue;
					}
				}
			}


for(i=1;i<=nx;i++)
			{
				for(j=1;j<=ny;j++)
				{
					for(k=1;k<=nz;k++)
					{
							if((phi_t[i][j][k]>1.0+eps)||(phi_t[i][j][k]<-eps))
							{
							forlorn=2;
							printf("%d\t%d\t%d\t%f\n",i,j,k,phi_t[i][j][k]);
							break;
							}else
								continue;

					}
				}
			}
	}while(forlorn>0);

}




void func1()
{

phi_max=0.0;
s=i-I;
m=j-I;
n=k-I;
do
{
		if(s!=i && m!=j && n!=k)
			{
				if(phi_max<phi_t[s][m][n])
					{
						phi_max=phi_t[s][m][n];
						ar=s;
						br=m;
						cr=n;
					}
			}else
				continue;

s++;
m++;
n++;
}while(s==(i+I) && m==(j+I) && n==(k+I));

phi_temp=phi_max+(phi_t[i][j][k]-1.0);
phi_t[ar][br][cr]=fmin(phi_temp,1.0);
phi_t[i][j][k]=1.0;//fmax(phi_temp,1.0);
}

void func2()
{

phi_min=0.0;
s=i-I;
m=j-I;
n=k-I;
do
{
		if(s!=i && m!=j && n!=k)
			{
				if(phi_min>phi_t[s][m][n])
					{
						phi_min=phi_t[s][m][n];
						dr=s;
						er=m;
						fr=n;
					}
			}else
				continue;

s++;
m++;
n++;
}while(s==(i+I) && m==(j+I) && n==(k+I));

phi_temp=phi_min+(phi_t[i][j][k]);
phi_t[dr][er][fr]=fmax(phi_temp,0.0);
phi_t[i][j][k]=0.0;//fmin(phi_temp,0.0);
}

//		--------------------------------------declaring vertices--------------------------------------//
void cv()			//				Cell Vertices
				// 		4(top left)		3(top right)
 				//		1(bottom left)	 	2(bottom right)
{
	xv[1]=xp[i];		yv[1]=yp[j];	zv[1]=zp[k];
	xv[2]=xp[i+1];		yv[2]=yp[j];	zv[2]=zp[k];
	xv[3]=xp[i+1];		yv[3]=yp[j+1];	zv[3]=zp[k];
	xv[4]=xp[i];		yv[4]=yp[j+1];	zv[4]=zp[k];

	xv[5]=xp[i];		yv[5]=yp[j];	zv[5]=zp[k+1];
	xv[6]=xp[i+1];		yv[6]=yp[j];	zv[6]=zp[k+1];
	xv[7]=xp[i+1];		yv[7]=yp[j+1];	zv[7]=zp[k+1];
	xv[8]=xp[i];		yv[8]=yp[j+1];	zv[8]=zp[k+1];
}

//Boundary Conditions
void BC()
{

	for(j=1;j<=ny;j++)
			{
				for(k=1;k<=nz;k++)
				{
					//----------------------- west face ----------------------------------//
					u[0][j][k]=u[nx][j][k];
			//		u[-1][j][k]=u[nx-1][j][k];
			//		u[-2][j][k]=u[nx-2][j][k];

					v[0][j][k]=v[nx][j][k];
			//		v[-1][j][k]=v[nx-1][j][k];
			//		v[-2][j][k]=v[nx-2][j][k];

					w[0][j][k]=w[nx][j][k];
			//		w[-1][j][k]=w[nx-1][j][k];
			//		w[-2][j][k]=w[nx-2][j][k];

					phi[0][j][k]=phi[nx][j][k];
			//		phi[-1][j][k]=phi[nx-1][j][k];
			//		phi[-2][j][k]=phi[nx-2][j][k];

					phi_t[0][j][k]=phi_t[nx][j][k];
			//		phi_t[-1][j][k]=phi_t[nx-1][j][k];
			//		phi_t[-2][j][k]=phi_t[nx-2][j][k];

	//----------------------- east face -----------------------------------//
					u[nx+1][j][k]=u[1][j][k];
			//		u[nx+2][j][k]=u[2][j][k];
			//		u[nx+3][j][k]=u[3][j][k];

					v[nx+1][j][k]=v[1][j][k];
			//		v[nx+2][j][k]=v[2][j][k];
			//		v[nx+3][j][k]=v[3][j][k];

					w[nx+1][j][k]=w[1][j][k];
			//		w[nx+2][j][k]=w[2][j][k];
			//		w[nx+3][j][k]=w[3][j][k];

					phi[nx+1][j][k]=phi[1][j][k];
			//		phi[nx+2][j][k]=phi[2][j][k];
			//		phi[nx+3][j][k]=phi[3][j][k];

					phi_t[nx+1][j][k]=phi_t[1][j][k];
			//		phi_t[nx+2][j][k]=phi_t[2][j][k];
			//		phi_t[nx+3][j][k]=phi_t[3][j][k];
				}
			}
			//-------------------------------- in y direction --------------------------------//
			for(i=1;i<=nx;i++)
			{
				for(k=1;k<=nz;k++)
				{
					//---------------------- south face -----------------------------//
					u[i][0][k]=u[i][ny][k];
			//		u[i][0][k]=u[i][ny-1][k];
			//		u[i][0][k]=u[i][ny-2][k];

					v[i][0][k]=v[i][ny][k];
			//		v[i][0][k]=v[i][ny-1][k];
			//		v[i][0][k]=v[i][ny-2][k];

					w[i][0][k]=w[i][ny][k];
			//		w[i][0][k]=w[i][ny-1][k];
			//		w[i][0][k]=w[i][ny-2][k];

					phi[i][0][k]=phi[i][ny][k];
			//		phi[i][0][k]=phi[i][ny-1][k];
			//		phi[i][0][k]=phi[i][ny-2][k];

					phi_t[i][0][k]=phi_t[i][ny][k];
			//		phi_t[i][0][k]=phi_t[i][ny-1][k];
			//		phi_t[i][0][k]=phi_t[i][ny-2][k];
					//--------------------- north face ------------------------------//
					u[i][ny+1][k]=u[i][1][k];
			//		u[i][ny+2][k]=u[i][2][k];
			//		u[i][ny+3][k]=u[i][3][k];

					v[i][ny+1][k]=v[i][1][k];
			//		v[i][ny+2][k]=v[i][2][k];
			//		v[i][ny+3][k]=v[i][3][k];

					w[i][ny+1][k]=w[i][1][k];
			//		w[i][ny+2][k]=w[i][2][k];
			//		w[i][ny+3][k]=w[i][3][k];

					phi[i][ny+1][k]=phi[i][1][k];
			//		phi[i][ny+2][k]=phi[i][2][k];
			//		phi[i][ny+3][k]=phi[i][3][k];

					phi_t[i][ny+1][k]=phi_t[i][1][k];
			//		phi_t[i][ny+2][k]=phi_t[i][2][k];
			//		phi_t[i][ny+3][k]=phi_t[i][3][k];
				}
			}
			//----------------------------- in z direction ----------------------------------------//
			for(i=1;i<=nx;i++)
			{
				for(j=1;j<=ny;j++)
				{
					//---------------------------- bottom face -----------------------------//
					u[i][j][0]=u[i][j][nz];
			//		u[i][j][-1]=u[i][j][nz-1];
			//		u[i][j][-2]=u[i][j][nz-2];

					v[i][j][0]=v[i][j][nz];
			//		v[i][j][-1]=v[i][j][nz-1];
			//		v[i][j][-2]=v[i][j][nz-2];

					w[i][j][0]=w[i][j][nz];
			//		w[i][j][-1]=w[i][j][nz-1];
			//		w[i][j][-2]=w[i][j][nz-2];

					phi[i][j][0]=phi[i][j][nz];
			//		phi[i][j][-1]=phi[i][j][nz-1];
			//		phi[i][j][-2]=phi[i][j][nz-2];

					phi_t[i][j][0]=phi_t[i][j][nz];
			//		phi_t[i][j][-1]=phi_t[i][j][nz-1];
			//		phi_t[i][j][-2]=phi_t[i][j][nz-2];
					//----------------------------- top face ------------------------------//
					u[i][j][nz+1]=u[i][j][1];
			//		u[i][j][nz+2]=u[i][j][2];
			//		u[i][j][nz+3]=u[i][j][3];

					v[i][j][nz+1]=v[i][j][1];
			//		v[i][j][nz+2]=v[i][j][2];
			//		v[i][j][nz+3]=v[i][j][3];

					w[i][j][nz+1]=w[i][j][1];
			//		w[i][j][nz+2]=w[i][j][2];
			//		w[i][j][nz+3]=w[i][j][3];

					phi[i][j][nz+1]=phi[i][j][1];
			//		phi[i][j][nz+2]=phi[i][j][2];
			//		phi[i][j][nz+3]=phi[i][j][3];

					phi_t[i][j][nz+1]=phi_t[i][j][1];
			//		phi_t[i][j][nz+2]=phi_t[i][j][2];
			//		phi_t[i][j][nz+3]=phi_t[i][j][3];
				}
			}

}


int l;
double alpha = 1.0;
double be,bw,bn,bs,bt,bb;
double ase,asw,asn,ass,ast,asb;
double sum,res,ap,rms;
double mass_initial,mass_final,mass_loss;

double cicsam();
void donor_acceptor_upwind_x(int,int,int,double);
void donor_acceptor_upwind_y(int,int,int,double);
void donor_acceptor_upwind_z(int,int,int,double);
void courant(int,int,int);

double ae,aw,an,as,at,ab,check;
double ad,au,aa,atd,atfc,atfu,mdiva,diva;
double cd,yy;
double theta,thetaf,dir,vdir,atil,b;
double ude,udw,vdn,vds,wdt,wdb,blend,atfc1,atfc2;


void courant(int i2,int j2,int k2)
{

	cd=0.0;
	ude=0.5*(u[i2][j2][k2]+u[i2+1][j2][k2]);
	udw=0.5*(u[i2][j2][k2]+u[i2-1][j2][k2]);
	vdn=0.5*(v[i2][j2][k2]+v[i2][j2+1][k2]);
	vds=0.5*(v[i2][j2][k2]+v[i2][j2-1][k2]);
	wdt=0.5*(w[i2][j2][k2]+w[i2][j2][k2+1]);
	wdb=0.5*(w[i2][j2][k2]+w[i2][j2][k2-1]);
	cd=cd+fmax(-ude*dt/dx,0.0);
	cd=cd+fmax(udw*dt/dx,0.0);
	cd=cd+fmax(-vdn*dt/dy,0.0);
	cd=cd+fmax(vds*dt/dy,0.0);
	cd=cd+fmax(-wdt*dt/dz,0.0);
	cd=cd+fmax(wdb*dt/dz,0.0);
}
//*********************donor_acceptor_upwind for x direction***************************//
void donor_acceptor_upwind_x(int i3,int j3,int k3,double ud)
{
	if(ud>=0.0)
	{
		ad=phi[i3][j3][k3];
		aa=phi[i3+1][j3][k3];
		au=phi[i3-1][j3][k3];
		ae=0.5*(phi[i3][j3][k3]+phi[i3+1][j3][k3]);
		aw=0.5*(phi[i3][j3][k3]+phi[i3-1][j3][k3]);
		an=0.5*(phi[i3][j3][k3]+phi[i3][j3+1][k3]);
		as=0.5*(phi[i3][j3][k3]+phi[i3][j3-1][k3]);
		at=0.5*(phi[i3][j3][k3]+phi[i3][j3][k3+1]);
		ab=0.5*(phi[i3][j3][k3]+phi[i3][j3][k3-1]);
		diva=ae-aw;
		mdiva=sqrt(((ae-aw)/dx)*((ae-aw)/dx)+((an-as)/dy)*((an-as)/dy)+((at-ab)/dz)*((at-ab)/dz))*sqrt(dx*dx);
	}
	else
	{
		ad=phi[i3+1][j3][k3];
		aa=phi[i3][j3][k3];
		au=phi[i3+2][j3][k3];
		ae=0.5*(phi[i3+1][j3][k3]+phi[i3+2][j3][k3]);
		aw=0.5*(phi[i3+1][j3][k3]+phi[i3][j3][k3]);
		an=0.5*(phi[i3+1][j3][k3]+phi[i3+1][j3+1][k3]);
		as=0.5*(phi[i3+1][j3][k3]+phi[i3+1][j3-1][k3]);
		at=0.5*(phi[i3+1][j3][k3]+phi[i3+1][j3][k3+1]);
		ab=0.5*(phi[i3+1][j3][k3]+phi[i3+1][j3][k3-1]);
		diva=ae-aw;
		mdiva=sqrt(((ae-aw)/dx)*((ae-aw)/dx)+((an-as)/dy)*((an-as)/dy)+((at-ab)/dz)*((at-ab)/dz))*sqrt(dx*dx);
	}
}
//*********************donor_acceptor_upwind for y direction***************************//
void donor_acceptor_upwind_y(int i1,int j1,int k1,double vd)
{
	if(vd>=0.0)
	{
		ad=phi[i1][j1][k1];
		aa=phi[i1][j1+1][k1];
		au=phi[i1][j1-1][k1];
		ae=0.5*(phi[i1][j1][k1]+phi[i1+1][j1][k1]);
		aw=0.5*(phi[i1][j1][k1]+phi[i1-1][j1][k1]);
		an=0.5*(phi[i1][j1][k1]+phi[i1][j1+1][k1]);
		as=0.5*(phi[i1][j1][k1]+phi[i1][j1-1][k1]);
		at=0.5*(phi[i1][j1][k1]+phi[i1][j1][k1+1]);
		ab=0.5*(phi[i1][j1][k1]+phi[i1][j1][k1-1]);
		diva=an-as;
		mdiva=sqrt(((ae-aw)/dx)*((ae-aw)/dx)+((an-as)/dy)*((an-as)/dy)+((at-ab)/dz)*((at-ab)/dz))*sqrt(dy*dy);
	}
	else
	{
		ad=phi[i1][j1+1][k1];
		aa=phi[i1][j1][k1];
		au=phi[i1][j1+2][k1];
		ae=0.5*(phi[i1][j1+1][k1]+phi[i1+1][j1+1][k1]);
		aw=0.5*(phi[i1][j1+1][k1]+phi[i1-1][j1+1][k1]);
		an=0.5*(phi[i1][j1+1][k1]+phi[i1][j1+2][k1]);
		as=0.5*(phi[i1][j1+1][k1]+phi[i1][j1][k1]);
		at=0.5*(phi[i1][j1+1][k1]+phi[i1][j1+1][k1+1]);
		ab=0.5*(phi[i1][j1+1][k1]+phi[i1][j1+1][k1-1]);
		diva=an-as;
		mdiva=sqrt(((ae-aw)/dx)*((ae-aw)/dx)+((an-as)/dy)*((an-as)/dy)+((at-ab)/dz)*((at-ab)/dz))*sqrt(dy*dy);
	}
}
//***************************donor_acceptor_upwind for z direction*************************//
void donor_acceptor_upwind_z(int i1,int j1,int k1,double wd)
{
	if(wd>=0.0)
	{
		ad=phi[i1][j1][k1];
		aa=phi[i1][j1][k1+1];
		au=phi[i1][j1][k1-1];
		ae=0.5*(phi[i1][j1][k1]+phi[i1+1][j1][k1]);
		aw=0.5*(phi[i1][j1][k1]+phi[i1-1][j1][k1]);
		an=0.5*(phi[i1][j1][k1]+phi[i1][j1+1][k1]);
		as=0.5*(phi[i1][j1][k1]+phi[i1][j1-1][k1]);
		at=0.5*(phi[i1][j1][k1]+phi[i1][j1][k1+1]);
		ab=0.5*(phi[i1][j1][k1]+phi[i1][j1][k1-1]);
		diva=at-ab;
		mdiva=sqrt(((ae-aw)/dx)*((ae-aw)/dx)+((an-as)/dy)*((an-as)/dy)+((at-ab)/dz)*((at-ab)/dz))*sqrt(dz*dz);
	}
	else
	{
		ad=phi[i1][j1][k1+1];
		aa=phi[i1][j1][k1];
		au=phi[i1][j1][k1+2];
		ae=0.5*(phi[i1][j1][k1+1]+phi[i1+1][j1][k1+1]);
		aw=0.5*(phi[i1][j1][k1+1]+phi[i1-1][j1][k1+1]);
		an=0.5*(phi[i1][j1][k1+1]+phi[i1][j1+1][k1+1]);
		as=0.5*(phi[i1][j1][k1+1]+phi[i1][j1-1][k1+1]);
		at=0.5*(phi[i1][j1][k1+1]+phi[i1][j1][k1+2]);
		ab=0.5*(phi[i1][j1][k1+1]+phi[i1][j1][k1]);
		diva=at-ab;
		mdiva=sqrt(((ae-aw)/dx)*((ae-aw)/dx)+((an-as)/dy)*((an-as)/dy)+((at-ab)/dz)*((at-ab)/dz))*sqrt(dz*dz);
	}
}
//*************************************cicsam scheme************************************//
double cicsam()
{
	if(ad!=1.0 || fabs(ad)>eps)
	{
		//****************tilda donor calculation***********************//
		if(fabs(aa-au)<eps)
		{
			atd=ad;
		}
		else
		{
			atd=(ad-au)/(aa-au);
		}

		//****************tilda face value******************************//
		if(scheme==1)// SAISH
		{
		//****************convective boundedness scheme*****************//
		
		//cbc scheme
		if(atd>=0.0 && atd<=1.0/4.0)
			atfc=4.0*atd;
		else if(atd>1.0/4.0  &&  atd<=1.0)
			atfc=1.0;
		else
			atfc=atd;


		if(atd>=0.0 && atd<=1.0/2.0)
			 atfu=atd*(2.0-atd);			//CLAM	or HLPA
		else if(atd>1.0/2.0 && atd<=3.0/4.0)
			atfu=atd+0.25;					// Fromm's
		else if(atd>3.0/4.0 && atd<=1.0)
			atfu=1.0;
		else
			atfu=atd;

	
		}else if(scheme==2) //FBICS
			{
				//****************convective boundedness scheme*****************//
				if(atd>=0.0 && atd<=1.0/3.0)
					atfc=3.0*atd;
				else if(atd>1.0/3.0  &&  atd<=1.0)
					atfc=1.0;
				else
					atfc=atd;
					//****************HR******************************//
				if(atd>=0.0 && atd<=1.0/8.0)
					atfu=3.0*atd;
				else if(atd>1.0/8.0 && atd<=3.0/4.0)
					atfu=atd+0.25;
				else if(atd>3.0/4.0 && atd<=1.0)
					atfu=1.0;
				else
					atfu=atd;

			}else if (scheme==3) // Basic-CICSAM
				{
					//****************convective boundedness scheme*****************//
					if(atd<0.0 || atd>1.0)
					{
						atfc=atd;
					}
					else
					{
						atfc=fmin(1.0,(atd/cd));
					}
					//****************ultimate quickest******************************//
					if(atd<0.0 || atd>1.0)
					{
						atfu=atd;
					}
					else
					{
						atfu=fmin(atfc,(8.0*cd*atd+(1.0-cd)*(6.0*atd+3.0))/8.0);
					}
				}else if (scheme==4) // CUIBS
					{
					//****************convective boundedness scheme*****************//
					if(atd>0.0 && atd<=1.0/3.0)
						atfc=3.0*atd;
					else if(atd>1.0/3.0  &&  atd<=1.0)
						atfc=1.0;
					else
						atfc=atd;
					//****************HR******************************//
					if(atd>=0.0 && atd<=2.0/13.0)
						atfu=3.0*atd;
					else if(atd>2.0/13.0 && atd<=4.0/5.0)
						atfu=5.0/6.0*atd+0.25;
					else if(atd>4.0/5.0 && atd<=1.0)
						atfu=1.0;
					else
						atfu=atd;

					}else if (scheme==5)//Modified-CICSAM
						{
								//****************convective boundedness scheme*****************//

								//SUPERBEE
								xnf=3.0/4.0;	xnd=0.5;	//only for uniform grids
								if((atd>=0 && atd<xnd/(2.0-xnd)))
									afsu=(2.0*xnf-xnd)/xnd*atd;
								else if (atd>=xnd/(2.0*xnd) && atd<xnd)
									afsu=(xnd-xnf)/(xnd-1.0)+(xnf-1.0)/(xnd-1.0)*atd;
								else if (atd>=xnd && atd<xnd/xnf)
									afsu=xnf/xnd*atd;
								else if (atd>=xnd/xnf && atd<=1.0)
									afsu=1.0;
								else
									afsu=atd;

								// CN-CBC
								if((atd>=0.0 && atd<=1.0) && (cd>0.0 && cd<=0.3))
									atfc=fmin(atd/0.3,1.0);
								else if ((atd>=0.0 && atd<=1.0) && (cd>0.3 && cd<=0.6))
									atfc=fmin(atd/0.3,1.0);
								else if ((atd>=0.0 && atd<=1.0) && (cd>0.6 && cd<=0.7))
									atfc=(0.7-cd)/0.1*fmin(atd/0.3,1.0)+(cd-0.6)/0.1*afsu;
								else if((atd>=0.0 && atd<=1.0) && cd>0.7)
									atfc=afsu;
								else if (atd>1.0 || atd<0.0)
									atfc=atd;

								//****************MUSCL******************************//
								if(atd>=0.0 && atd<xnd*0.5)
									atfu=(2.0*xnf-xnd)/xnd*atd;
								else if(atd>=0.5*xnd && atd<(1.0+xnd-xnf))
									atfu=xnf-xnd+atd;
								else if(atd>=(1.0+xnd-xnf) && atd<=1.0)
									atfu=1.0;
								else
									atfu=atd;

						}

		ep=2.0;

		theta=acos(fabs(diva/mdiva));
		if(scheme==2 || scheme==4)
		yy=fmin(pow(cos(theta),4.0),1.0);
		else if(scheme==1 || scheme==5)
		yy=fmin(pow(fabs(diva/mdiva),ep),1.0);
		else
			yy=fmin((cos(2.0*theta)+1.0)/2.0,1.0);	//3
		//****************tilda face calculation************************//
		atil=yy*atfc+(1-yy)*atfu;
		//******************************weighting factor calculation****************//
		if(fabs(1.0-atd)<=eps)
		{
			b=0.5;
		}
		else
		{
			b=(atil-atd)/(1.0-atd);
		}
	}
	else
	{
		b=0.0;
	}
	return(b);
}


void VOF()
{
		//**************************main iteration*****************************************//
		l=1;
		do
		{
		BC();
			sum=0.0;
//#pragma omp parallel for collapse(3) schedule(static) default(shared) private(ue,uw,vn,vs,wb,wt,be,ase,asw,asn,ass,ast,asb,res,ap,aa,ad,au,ae,aw,an,as,at,ab,diva,mdiva,atd,atfc1,atfc2,atfc,atfu,xnf,xnd,theta,yy,atil,b,cd) reduction(+:sum)
			for(i=1;i<=nx;i++)
			{
				for(j=1;j<=ny;j++)
				{
					for(k=1;k<=nz;k++)
					{
						ue=0.5*(u[i][j][k]+u[i+1][j][k]);
						uw=0.5*(u[i][j][k]+u[i-1][j][k]);
						vn=0.5*(v[i][j][k]+v[i][j+1][k]);
						vs=0.5*(v[i][j][k]+v[i][j-1][k]);
						wt=0.5*(w[i][j][k]+w[i][j][k+1]);
						wb=0.5*(w[i][j][k]+w[i][j][k-1]);
						ap=0.0;
						if(ue>=0.0)
						{
							donor_acceptor_upwind_x(i,j,k,ue);
							courant(i,j,k);
							be=cicsam();
							ase=((1.0-be)*(phi[i][j][k]+phi_t[i][j][k])*0.5)+(0.5*be*(phi[i+1][j][k]+phi_t[i+1][j][k]));
							ap=ap-(0.5*(1.0-be)*ue*(dt/dx));
						}
						else
						{
							donor_acceptor_upwind_x(i,j,k,ue);
							courant(i+1,j,k);
							be=cicsam();
							ase=((1.0-be)*0.5*(phi[i+1][j][k]+phi_t[i+1][j][k]))+(0.5*be*(phi[i][j][k]+phi_t[i][j][k]));
							ap=ap-(0.5*be*ue*(dt/dx));
						}
						if(uw>=0.0)
						{
							donor_acceptor_upwind_x(i-1,j,k,uw);
							courant(i-1,j,k);
							bw=cicsam();
							asw=((1.0-bw)*(phi[i-1][j][k]+phi_t[i-1][j][k])*0.5)+(0.5*bw*(phi[i][j][k]+phi_t[i][j][k]));
							ap=ap-(0.5*bw*uw*(-dt/dx));
						}
						else
						{
							donor_acceptor_upwind_x(i-1,j,k,uw);
							courant(i,j,k);
							bw=cicsam();
							asw=((1.0-bw)*(phi[i][j][k]+phi_t[i][j][k])*0.5)+(0.5*bw*(phi[i-1][j][k]+phi_t[i-1][j][k]));
							ap=ap-(0.5*(1.0-bw)*uw*(-dt/dx));
						}
						if(vn>=0.0)
						{
							donor_acceptor_upwind_y(i,j,k,vn);
							courant(i,j,k);
							bn=cicsam();
							asn=((1.0-bn)*(phi[i][j][k]+phi_t[i][j][k])*0.5)+(0.5*bn*(phi[i][j+1][k]+phi_t[i][j+1][k]));
							ap=ap-(0.5*(1.0-bn)*vn*(dt/dy));
						}
						else
						{
							donor_acceptor_upwind_y(i,j,k,vn);
							courant(i,j+1,k);
							bn=cicsam();
							asn=((1.0-bn)*(phi[i][j+1][k]+phi_t[i][j+1][k])*0.5)+(0.5*bn*(phi[i][j][k]+phi_t[i][j][k]));
							ap=ap-(0.5*bn*vn*(dt/dy));
						}
						if(vs>=0.0)
						{
							donor_acceptor_upwind_y(i,j-1,k,vs);
							courant(i,j-1,k);
							bs=cicsam();
							ass=((1.0-bs)*(phi[i][j-1][k]+phi_t[i][j-1][k])*0.5)+(0.5*bs*(phi[i][j][k]+phi_t[i][j][k]));
							ap=ap-(0.5*bs*vs*(-dt/dy));
						}
						else
						{
							donor_acceptor_upwind_y(i,j-1,k,vs);
							courant(i,j,k);
							bs=cicsam();
							ass=((1.0-bs)*(phi[i][j][k]+phi_t[i][j][k])*0.5)+(0.5*bs*(phi[i][j-1][k]+phi_t[i][j-1][k]));
							ap=ap-(0.5*(1.0-bs)*vs*(-dt/dy));
						}
						if(wt>=0.0)
						{
							donor_acceptor_upwind_z(i,j,k,wt);
							courant(i,j,k);
							bt=cicsam();
							ast=((1.0-bt)*(phi[i][j][k]+phi_t[i][j][k])*0.5)+(0.5*bt*(phi[i][j][k+1]+phi_t[i][j][k+1]));
							ap=ap-(0.5*(1.0-bt)*wt*(dt/dz));
						}
						else
						{
							donor_acceptor_upwind_z(i,j,k,wt);
							courant(i,j,k+1);
							bt=cicsam();
							ast=((1.0-bt)*(phi[i][j][k+1]+phi_t[i][j][k+1])*0.5)+(0.5*bt*(phi[i][j][k]+phi_t[i][j][k]));
							ap=ap-(0.5*bt*wt*(dt/dz));
						}
						if(wb>=0.0)
						{
							donor_acceptor_upwind_z(i,j,k-1,wb);
							courant(i,j,k-1);
							bb=cicsam();
							asb=((1.0-bb)*(phi[i][j][k-1]+phi_t[i][j][k-1])*0.5)+(0.5*bb*(phi[i][j][k]+phi_t[i][j][k]));
							ap=ap-(0.5*bb*wb*(-dt/dz));
						}
						else
						{
							donor_acceptor_upwind_z(i,j,k-1,wb);
							courant(i,j,k);
							bb=cicsam();
							asb=((1.0-bb)*(phi[i][j][k]+phi_t[i][j][k])*0.5)+(0.5*bb*(phi[i][j][k-1]+phi_t[i][j][k-1]));
							ap=ap-(0.5*(1.0-bb)*wb*(-dt/dz));
						}
				 	 	ap=-(ap-1.0);
						res=-((ase*ue*dy*dz)-(asw*uw*dy*dz)+(asn*vn*dx*dz)-(ass*vs*dx*dz)+(ast*wt*dx*dy)-(asb*wb*dx*dy))*(dt/(dx*dy*dz))+phi[i][j][k]-phi_t[i][j][k];
						phi_t[i][j][k]=phi_t[i][j][k]+(res*alpha/ap);
						sum=sum+(res*res);
					}
				}
			}
			rms=sqrt(sum/(nx*ny*nz));

			l=l+1;
		}while(rms>1e-13);
		printf("\n rms = %.17f \t n = %d\n",rms,l);
		//**************************check for over shoot and under shoot**********************/
//_______________________________Redistribution____________________________________

redistribution();
//**************************new value assigned to old value**************************/
	for(i=1;i<=nx;i++)
		{
			for(j=1;j<=ny;j++)
			{
				for(k=1;k<=nz;k++)
				{
					phi[i][j][k]=phi_t[i][j][k];
				}
			}
    	}
		//****************************iteration ends here**************************************//
}


