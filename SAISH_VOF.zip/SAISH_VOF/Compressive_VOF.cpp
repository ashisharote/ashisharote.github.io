//		-------------------Advection with Operator split and Dilatation(with truncation-------------------------//
//		--for heart--
//		x_centre=0.5; 	y_centre=0.32;   R=0.17;
//
//		--for Torsten Stillke's Flower--
//		L=2.0; H=2.0; R=0.0; with change in R you can find wiggles
//
//		_______________________________________________________________________________________________________//
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<omp.h>
#include"functions.h"
#include <time.h>
double dtmax;
main()
{

printf("\n SAISH => 1\n\n FBICS => 2\n\n Basic CICSAM => 3\n\n CUIBS => 4\n\n Modified CICSAM => 5\n\n\t");
scanf("%d",&scheme);
//omp_set_num_threads(4);
//		--------------------------------domain and essentials--------------------------------------//
L=1.0;
H=1.0;
W=2.0;
nx=64;
ny=64;
nz=128;
dx=L/nx;
dy=H/ny;
dz=W/nz;
x_centre=0.5;
y_centre=0.75;
z_centre=0.25;

R=0.15;
dt=0.0009034*4;
dtmax=dt;
//		----------------------------------PLIC Grid-----------------------------------------------//
xp[1]=0.0;
for(i=2;i<=nx+1;i++)
	xp[i]=xp[i-1]+dx;

yp[1]=0.0;
for(j=2;j<=ny+1;j++)
	yp[j]=yp[j-1]+dy;

zp[1]=0.0;
for(k=2;k<=nz+1;k++)
	zp[k]=zp[k-1]+dz;


//		--------------------------------------FVM Grid--------------------------------------------//
x[1]=0.5*dx;
for(i=2;i<=nx;i++)
	x[i]=x[i-1]+dx;

y[1]=0.5*dy;
for(j=2;j<=ny;j++)
	y[j]=y[j-1]+dy;

z[1]=0.5*dz;
for(k=2;k<=nz;k++)
	z[k]=z[k-1]+dz;
/*
//Known Velocity
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
		for(k=1;k<=nz;k++)
			{
			u[i][j][k]=2.0*pow(sin(M_PI*x[i]),2.0)*sin(2.0*M_PI*y[j])*sin(2.0*M_PI*z[k])*cos(M_PI*time/3.0);
			v[i][j][k]=-2.0*pow(sin(M_PI*y[j]),2.0)*sin(2.0*M_PI*x[i])*sin(2.0*M_PI*z[k])*cos(M_PI*time/3.0);
			w[i][j][k]=-2.0*pow(sin(M_PI*z[k]),2.0)*sin(2.0*M_PI*x[i])*sin(2.0*M_PI*y[j])*cos(M_PI*time/3.0);
//			u[i][j]=(1-x[i]); // Pichku test
//			v[i][j]=0.0;//(1.0-y[j]); // Pichku test
//        	u[i][j][k]=(1.0/8.0)*(8.0*x[i]-4.0); // Droplet test
//			v[i][j][k]=(1.0/8.0)*(-(8.0*y[j]-4.0)-4.0-1.0+pow(8.0*x[i]-4.0,2.0)+pow(8.0*x[i]-4.0,4.0));//(1.0-y[j]); // Droplet test
//        	u[i][j][k]=0.25*((4.0*x[i]-2.0)+pow((4.0*y[j]-2.0),3.0)); // Superman Flow
 //      	v[i][j][k]=-0.25*((4.0*y[j]-2.0)+pow((4.0*x[i]-2.0),3.0)); // Superman Flow
// 			u[i][j]=(sin(4.0*M_PI*x[i]+2.0*M_PI)*sin(4.0*M_PI*y[j]+2.0*M_PI)); //Deformation_test (Rider-kothe)
//			v[i][j]=(cos(4.0*M_PI*x[i]+2.0*M_PI)*cos(4.0*M_PI*y[j]+2.0*M_PI)); //Deformation_test (Rider-Kothe)
//			u[i][j][k]=0.25;
//			v[i][j][k]=0.25;
//			w[i][j][k]=0.0;
			}
        }
	}
*/
//		-------------------------------------Patching-intializing---------------------------------//
float xt,yt,zt,dmx,dmy,dmz;
//#pragma omp parallel for collapse(3) schedule(static) default(shared) private(xt,yt,zt,count)
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
		for(k=1;k<=nz;k++)
			{
			count=0;
			cv();
			for(p=1;p<=8;p++)
				{
				//---------------------------Heart------------------------------------------------------------------
//				pow(xv[p]-x_centre,2.0)+pow(5.0*(yv[p]-y_centre)/4.0-sqrt(fabs(xv[p]-x_centre)),2)-R<=0.0?count++:0;
				//---------------------------Circle-----------------------------------------------------------------
				pow(xv[p]-x_centre,2.0)+pow(yv[p]-y_centre,2.0)+pow(zv[p]-z_centre,2.0)-R*R<=0.0?count++:0;
				//---------------------------Square(rotated)--------------------------------------------------------
//				fabs(xv[p]-x_centre)+fabs(yv[p]-y_centre)-R<=0.0?count++:0;
				//-----------------------Egg-Peanut-----------------------------------------------------------------
//				(pow(xv[p]-x_centre-1,2.0)+pow(yv[p]-y_centre,2.0))*(pow(xv[p]+x_centre-1,2.0)+pow(yv[p]-y_centre,2.0))-R<=0.0?count++:0;
				//-----------------------Torsten Sillke's flower----------------------------------------------------
//				pow((pow((xv[p]-x_centre),2.0)+pow((yv[p]-y_centre),2.0)),3.0)-4.0*(pow((xv[p]-x_centre),2.0))*pow((yv[p]-y_centre),2.0)-R<=0.0?count++:0;
				}
				if(count==8)
				phi[i][j][k]=1.0;
				else if(count==0)
				phi[i][j][k]=0.0;
			else
			{
				int mx=100,my=100,mz=100;
				dmx=dx/mx;
				dmy=dy/my;
				dmz=dz/mz;
				count=0;
					for(p1=1;p1<=mx;p1++)
						{
						for(q=1;q<=my;q++)
							{
							for(r=1;r<=mz;r++)
								{
									xt=xv[1]+(p1-0.5)*dmx;
									yt=yv[1]+(q-0.5)*dmy;
									zt=zv[1]+(r-0.5)*dmz;
					//---------------------------Heart------------------------------------------------------------------
//					pow(xt-x_centre,2.0)+pow(5.0*(yt-y_centre)/4.0-sqrt(fabs(xt-x_centre)),2)-R<=0.0?count++:0;
					//---------------------------------Circle-----------------------------------------------------
					pow(xt-x_centre,2.0)+pow(yt-y_centre,2.0)+pow(zt-z_centre,2.0)-R*R <=0.0?count++:0;
					//---------------------------Square(rotated)--------------------------------------------------------
//					fabs(xt-x_centre)+fabs(yt-y_centre)-R<=0.0?count++:0;
					//-----------------------Egg-Peanut-----------------------------------------------------------------
//					(pow(xt-x_centre-1,2.0)+pow(yt-y_centre,2.0))*(pow(xt+x_centre-1,2.0)+pow(yt-y_centre,2.0))-R<=0.0?count++:0;
					//-----------------------Torsten Sillke's flower----------------------------------------------------
//					pow((pow((xt-x_centre),2.0)+pow((yt-y_centre),2.0)),3.0)-4.0*(pow((xt-x_centre),2.0))*pow((yt-y_centre),2.0)-R<=0.0?count++:0;
					 			}
							 }
						}
				phi[i][j][k]=(count*1.0)/(mx*my*mz); //total vol. fraction in cell [i,j]=No.of cells inside/total cells in cell [i,j]

			}

			//	if((x[i]>=0.48 && x[i]<=0.52) && (y[j]>=0.5 && y[j]<=0.8))  //Zalesak Sphere
			//	phi[i][j][k]=0.0;

		}
	}
}
double	m_initial=0.0;
//#pragma omp parallel for collapse(3) schedule(static) default(shared) reduction(+:m_initial)
	for(i=1;i<=nx;i++)
    	{
        	for(j=1;j<=ny;j++)
        	{
            	for(k=1;k<=nz;k++)
				{
					m_initial=m_initial+(phi[i][j][k]*dx*dy*dz);
				}
        	}
    	}
tc=0;
printf("Patching done ......\n");
tim=dt;
double T=6.0;
//for(tc=1;tc<=1661;tc++)
 clock_t tStart = clock();
do
{

//Known Velocity
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
		for(k=1;k<=nz;k++)
			{
            //Zalesak's sphere
	//		u[i][j][k]=0.5-y[j];
	//		v[i][j][k]=x[i]-0.5;
	//		w[i][j][k]=0.0;


			double r;
			r=sqrt((x[i]-0.5)*(x[i]-0.5)+(y[j]-0.5)*(y[j]-0.5));
			u[i][j][k]=sin(pi*x[i])*sin(pi*x[i])*sin(2*pi*y[j])*cos(pi*tim/T);
			v[i][j][k]=-sin(2*pi*x[i])*sin(pi*y[j])*sin(pi*y[j])*cos(pi*tim/T);
			w[i][j][k]=(1.0-(r/0.5))*(1.0-(r/0.5))*cos(pi*tim/T);
		//	Single Vortex
		//	double r;
		//	r=sqrt((x[i]-0.5)*(x[i]-0.5)+(y[j]-0.5)*(y[j]-0.5));
		//	u[i][j][k]=sin(pi*x[i])*sin(pi*x[i])*sin(2*pi*y[j])*cos(pi*time/T);
		//	v[i][j][k]=-sin(2*pi*x[i])*sin(pi*y[j])*sin(pi*y[j])*cos(pi*time/T);
		//	w[i][j][k]=(1.0-(r/0.5))*(1.0-(r/0.5))*cos(pi*time/T);
//			u[i][j]=(1-x[i]); // Pichku test
//			v[i][j]=0.0;//(1.0-y[j]); // Pichku test
//	       	u[i][j][k]=(1.0/8.0)*(8.0*x[i]-4.0); // Droplet test
//			v[i][j][k]=(1.0/8.0)*(-(8.0*y[j]-4.0)-4.0-1.0+pow(8.0*x[i]-4.0,2.0)+pow(8.0*x[i]-4.0,4.0));//(1.0-y[j]); // Droplet test
 //       	u[i][j][k]=0.25*((4.0*x[i]-2.0)+pow((4.0*y[j]-2.0),3.0)); // Superman Flow
//      	v[i][j][k]=-0.25*((4.0*y[j]-2.0)+pow((4.0*x[i]-2.0),3.0)); // Superman Flow
// 			u[i][j]=(sin(4.0*M_PI*x[i]+2.0*M_PI)*sin(4.0*M_PI*y[j]+2.0*M_PI)); //Deformation_test (Rider-kothe)
//			v[i][j]=(cos(4.0*M_PI*x[i]+2.0*M_PI)*cos(4.0*M_PI*y[j]+2.0*M_PI)); //Deformation_test (Rider-Kothe)
//			u[i][j][k]=0.25;
//			v[i][j][k]=0.25;
//			w[i][j][k]=0.0;
			}
        }
	}


						VOF();

/*
FILE *f3;
if(tc%25==0)
{
sprintf (string, "./Data/patch%d.dat",tc/25);
f3=fopen(string,"w");
fprintf(f3,"\nVARIABLES=""X"",""Y"",""Z"",""phi"",""U-vel"",""V-vel"",""W-vel"" \nZONE I=%d,J=%d,K=%d ZONETYPE=ORDERED,DATAPACKING=POINT\n",nz,ny,nx);
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
		for(k=1;k<=nz;k++)
			{
				fprintf(f3,"\t%f\t%f\t%f\t%f\t%f\t%f\t%f\n",x[i],y[j],z[k],phi[i][j][k],u[i][j][k],v[i][j][k],w[i][j][k]);
			}
		}
	}
fclose(f3);
}
*/

			double vmax=0.0,umax=0.0,m_final=0.0;
			for(i=1;i<=nx;i++)
					{
					for(j=1;j<=ny;j++)
						{
						for(k=1;k<=nz;k++)
							{
							m_final=m_final+phi[i][j][k]*dx*dy*dz;
							if(fabs(v[i][j][k])>vmax)
								{
									vmax=v[i][j][k];

								}
							if(fabs(u[i][j][k])>umax)
								{
									umax=u[i][j][k];
								}
							}
						}
					}
			double co;

			if(vmax>umax)
			co=vmax*dt/dy;
			else
			co=umax*dt/dx;

			printf("\tCourant=%f\tdt=%f\tmass loss(%%)=%.20f\n\n",co,dt,fabs(m_initial-m_final)*100/(m_initial));
			if(co>0.9)
				dt=0.9*dt;
			else if(co<0.9)
				dt=1.02*dt;
printf("Time= %f \n",tim);
tc=tc+1;
tim=tim+dt;

if(tc%2==0)
{
FILE *f2;
f2=fopen("ep_MC.dat","a");
fprintf(f2,"%f\t%.25f\n",tim,fabs(m_initial-m_final)/(m_initial));
fclose(f2);

}while(tim<=T+dt);

//		-------------------------------------------File Writing-----------------------------------------//

FILE *f1;
f1=fopen("Plic_grid1.dat","w");
//fprintf(f1,"\nVARIABLES=""X"",""Y"", \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx+1,ny+1);
for(i=1;i<=nx+1;i++)
	{
	for(j=1;j<=ny+1;j++)
		{
			fprintf(f1,"\t%f\t%f\n",xp[i],yp[j]);

		}
		fprintf(f1,"\n");
	}
fclose(f1);

f1=fopen("Plic_grid2.dat","w");
//fprintf(f1,"\nVARIABLES=""X"",""Y"", \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx+1,ny+1);
for(j=1;j<=ny+1;j++)
	{
	for(i=1;i<=nx+1;i++)
		{
			fprintf(f1,"\t%f\t%f\n",xp[i],yp[j]);
		}
		fprintf(f1,"\n");
	}
fclose(f1);

FILE *f3;
f3=fopen("Patch.dat","w");
fprintf(f3,"\nVARIABLES=""X"",""Y"",""Z"",""phi"" \nZONE I=%d,J=%d,K=%d ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx,ny,nz);
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
		for(k=1;k<=nz;k++)
			{
				fprintf(f3,"\t%f\t%f\t%f\t%f\n",x[i],y[j],z[k],phi[i][j][k]);
			}
		}
	//	fprintf(f1,"\n");
	}
fclose(f3);

 printf("Time taken: %.2fs\n", (double)(clock() - tStart)/CLOCKS_PER_SEC);

FILE *f4;
f4=fopen("time_taken.dat","w");
fprintf(f4,"time Taken=%.2f\n",(double)(clock() - tStart)/CLOCKS_PER_SEC);
fclose(f4);
}
