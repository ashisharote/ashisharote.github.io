int i,j,nx,ny,count,n,q,a,tc,rcnst_count,scheme,order;
float x[1100],y[1100],dx,dy,L,H,x_centre,y_centre,phi[1100][1100],xv[5],yv[5],xb[1100],yb[1100],R;
float nr_x[1100][1100],nr_y[1100][1100],beta[1100][1100],x1_int[1100],y1_int[1100],x2_int[1100],y2_int[1100];
float sl[1100][1100],sb[1100][1100],sr[1100][1100],st[1100][1100],nr_x0[1100][1100],nr_y0[1100][1100];
float xp[1100],yp[1100],alp[1100][1100];
double time,dt,vel,s1,l1,gr,s2,l2,flx,Fr[1100][1100]={0.0},Fl[1100][1100]={0.0},Fb[1100][1100]={0.0},Ft[1100][1100]={0.0};
double phi_t[1100][1100],phinew[1100][1100],pl=0.0,pr=0.0,pb=0.0,pt=0.0,u[1100][1100],v[1100][1100],c;
char string[100];
double weight;
double Re,rel_fac,ut[1100][1100],vt[1100][1100],p[1100][1100],pc[1100][1100],Res,corr,aw,an,as,ae,cw,cs,cn,ce;
double sum,gsum,sqr,gsqr,diff,gdiff,RMS,gRMS,u0,ap,ue,uw,un,us,ve,vw,vn,vs,uwa,uea,usa,una,vsa,vea,vna,vwa,fyad,fydf,fxad,fxdf;
double s[1100][1100],uwp,uep,vnp,vsp,ute,utw,vts,vtn,pnew[1100][1100],unew[1100][1100],vnew[1100][1100],uc[1100][1100],vc[1100][1100];
double rho[1100][1100],visc[1100][1100],rho1,rho2,visc1,visc2,rhoe,rhow,rhon,rhos,viscw,visce,viscn,viscs,Froude;
double x1[1100],x2[1100],x3[1100],x4[1100],y11[1100],y2[1100],y3[1100],y4[1100],x5[1100],y5[1100],ca[1100][1100],uwaq,ueaq,usaq,unaq,vwaq,veaq,vsaq,vnaq;
double slope_ueh,slope_uwh,slope_unv,slope_usv,slope_veh,slope_vwh,slope_vnv,slope_vsv,a1,a2,a3,a4;
double a5,a6,a7,a8,a11,a22,a33,a44,a55,a66,a77,a88,lim_uw,lim_ue,lim_un,lim_us,lim_vw,lim_ve,lim_vn,lim_vs;
double uwl,vwl,uel,v_el,unl,vnl,usl,vsl;							
#define eps 1e-12// According to Rider-Kothe
#define eps1 1e-15
//		--------------------------------------Face Velocity function----------------------------------//
void fvel()
	{
		ue=(u[i+1][j]+u[i][j])/2.0;
		uw=(u[i-1][j]+u[i][j])/2.0;
		vn=(v[i][j+1]+v[i][j])/2.0;
		vs=(v[i][j-1]+v[i][j])/2.0;	
	}
void fvisc()
	{
		viscw=2.0*(visc[i][j]*visc[i-1][j])/(visc[i][j]+visc[i-1][j]);
		visce=2.0*(visc[i][j]*visc[i+1][j])/(visc[i][j]+visc[i+1][j]);
		viscn=2.0*(visc[i][j]*visc[i][j+1])/(visc[i][j]+visc[i][j+1]);
		viscs=2.0*(visc[i][j]*visc[i][j-1])/(visc[i][j]+visc[i][j-1]);
	}
		
void frho()
	{
		rhoe=(rho[i+1][j]+rho[i][j])/2.0;
		rhow=(rho[i-1][j]+rho[i][j])/2.0;
		rhon=(rho[i][j+1]+rho[i][j])/2.0;
		rhos=(rho[i][j-1]+rho[i][j])/2.0;	
	}
// Fluxes in pure cell	
void pure_water()
	{
				
					if(ue>0.0)
						{					
						vel=ue;
						Fr[i][j]=fabs(vel)*dt*dy;
						}
					else
						Fr[i][j]=0.0;

					if(uw<0.0)
						{
						vel=uw;
						Fl[i][j]=fabs(vel)*dt*dy;
						}
					else
						Fl[i][j]=0.0;

					if(vn>0.0)
						{
						vel=vn;
						Ft[i][j]=fabs(vel)*dt*dx;
						}
					else
						Ft[i][j]=0.0;

					if(vs<0.0)
						{
						vel=vs;	
						Fb[i][j]=fabs(vel)*dt*dx;
						}
					else
						Fb[i][j]=0.0;
	
	}
//		--------------------------------------declaring vertices--------------------------------------//
void cv()			//				Cell Vertices
				// 		4(top left)		3(top right)
 				//		1(bottom left)	 	2(bottom right)  
{
	xv[1]=xp[i];		yv[1]=yp[j];
	xv[2]=xp[i+1];		yv[2]=yp[j];
	xv[3]=xp[i+1];		yv[3]=yp[j+1];
	xv[4]=xp[i];		yv[4]=yp[j+1];
}

//		-------------------------------Reconstruction-------------------------------------------------//
void rcnst()
	{
// 		-----------------------------------Normals_and_angle_with_horizontal---------------------------
				nr_x[i][j]=(1/(8.0*dx))*(phi[i+1][j+1]+2.0*phi[i+1][j]+phi[i+1][j-1]-phi[i-1][j+1]-2.0*phi[i-1][j]-phi[i-1][j-1]);
				nr_y[i][j]=(1/(8.0*dy))*(phi[i+1][j+1]+2.0*phi[i][j+1]+phi[i-1][j+1]-phi[i+1][j-1]-2.0*phi[i][j-1]-phi[i-1][j-1]);
//		---------------------------------------Angle of interface with the horizontal---------------------
				alp[i][j]=(atan(-nr_x[i][j]/nr_y[i][j])); 	//radians
				beta[i][j]=atan((dx/dy)*tan(alp[i][j])); 	//radians
//		---------------------------------------When beta is -ve-------------------------------------------
				if((nr_x[i][j]>0.0 && nr_y[i][j]>0.0) ||(nr_x[i][j]<0.0 && nr_y[i][j]<0.0))
					beta[i][j]=M_PI/2.0+(beta[i][j]);

//		-------------------Case Identification(Rudman Algorithm)feat. Shashwat_sir-----------------------//
	if(beta[i][j]<(M_PI/4.0))
		{
			if (phi[i][j]<=0.5*tan(beta[i][j]))
//		----------------------------------CASE I---------------------------------
				{
				ca[i][j]=3;
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					sr[i][j]=sqrt(phi[i][j]*2.0*((tan(beta[i][j]))));
					sb[i][j]=sqrt(phi[i][j]*(1.0/tan(beta[i][j]))*2.0);
					sl[i][j]=0.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
										
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
					
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]-0.5*dy;
				//	printf("case I \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					sl[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					sb[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);
					sr[i][j]=0.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
					
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]-0.5*dy;
				//	printf("case I \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					st[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					sl[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);	
					sr[i][j]=0.0;
					sb[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
					
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]+0.5*dy;
				//	printf("case I \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sr[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					st[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);
					sb[i][j]=0.0;
					sl[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
				
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]+0.5*dy;				
				//	printf("case I \t q1 %d_%d",i,j);
					}					
			
				}
			else if(phi[i][j]<=(1.0-0.5*tan(beta[i][j])))	
				{
				ca[i][j]=4;
//		----------------------------------CASE II--------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					sr[i][j]=phi[i][j]+0.5*(tan(beta[i][j]));
					sl[i][j]=phi[i][j]-0.5*(tan(beta[i][j]));
					sb[i][j]=1.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx;
					y1_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
										
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
				
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]-0.5*dy;
					
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]-0.5*dy;
				//	printf("case II \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					st[i][j]=phi[i][j]-0.5*(tan(beta[i][j]));
					sb[i][j]=phi[i][j]+0.5*(tan(beta[i][j]));
					sr[i][j]=0.0;
					sl[i][j]=1.0;
					x1_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
				
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]+0.5*dy;
					
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]-0.5*dy;
				//	printf("case II \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					sr[i][j]=phi[i][j]-0.5*(tan(beta[i][j]));
					sl[i][j]=phi[i][j]+0.5*(tan(beta[i][j]));
					sb[i][j]=0.0;
					st[i][j]=1.0;
					
					x1_int[i]=x[i]-0.5*dx;
					y1_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
					
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]+0.5*dy;
					
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]+0.5*dy;
				//	printf("case II \t q2 %d_%d",i,j);	
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					st[i][j]=phi[i][j]+0.5*(tan(beta[i][j]));
					sb[i][j]=phi[i][j]-0.5*(tan(beta[i][j]));
					sr[i][j]=1.0;
					sl[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y2_int[j]=y[j]-0.5*dy;
			
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]-0.5*dy;
					
					x4[i]=x[i]+0.5*dx;
					y4[j]=y[j]+0.5*dy;
				//	printf("case II \t q1 %d_%d",i,j);	
					}
				}
			else 
				{
//		---------------------------------CASE IV---------------------------------
				ca[i][j]=5;
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					st[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sl[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sr[i][j]=1.0;
					sb[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
					
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]-0.5*dy;
					
					x4[i]=x[i]+0.5*dx;
					y4[j]=y[j]-0.5*dy;
					
					x5[i]=x[i]+0.5*dx;
					y5[j]=y[j]+0.5*dy;
				//	printf("case IV \t q4 %d_%d",i,j);
					}	
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					sr[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					st[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sl[i][j]=1.0;
					sb[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx;
					y1_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
					
					x2_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
			
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]+0.5*dy;
					
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]-0.5*dy;
					
					x5[i]=x[i]+0.5*dx;
					y5[j]=y[j]-0.5*dy;
			
				//	printf("case IV \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					sb[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sr[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					st[i][j]=1.0;
					sl[i][j]=1.0; 
					x1_int[i]=x[i]+0.5*dx;
					y1_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
					
					x2_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y2_int[j]=y[j]-0.5*dy;
		
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]-0.5*dy;
					
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]+0.5*dy;
					
					x5[i]=x[i]+0.5*dx;
					y5[j]=y[j]+0.5*dy;
			
				//	printf("case IV \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sl[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sb[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sr[i][j]=1.0;
					st[i][j]=1.0;					
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
	
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]+0.5*dy;
					
					x4[i]=x[i]+0.5*dx;
					y4[j]=y[j]+0.5*dy;
					
					x5[i]=x[i]+0.5*dx;
					y5[j]=y[j]-0.5*dy;
			
				//	printf("case IV \t q1 %d_%d",i,j);
					}
				}
		}
	else 
		{
			if(phi[i][j]<=0.5*(1.0/(tan(beta[i][j]))))
				{
				ca[i][j]=3;
//		-------------------------------CASE I------------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					sr[i][j]=sqrt(phi[i][j]*2.0*((tan(beta[i][j]))));
					sb[i][j]=sqrt(phi[i][j]*(1.0/tan(beta[i][j]))*2.0);
					sl[i][j]=0.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
										
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
					
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]-0.5*dy;
				//	printf("case I \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					sl[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					sb[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);
					sr[i][j]=0.0;
					st[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
					
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]-0.5*dy;
				//	printf("case I \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					st[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					sl[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);	
					sr[i][j]=0.0;
					sb[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
					
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]+0.5*dy;
				//	printf("case I \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sr[i][j]=sqrt(phi[i][j]*2.0*(1.0/(tan(beta[i][j]))));
					st[i][j]=sqrt(phi[i][j]*(tan(beta[i][j]))*2.0);
					sb[i][j]=0.0;
					sl[i][j]=0.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
				
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]+0.5*dy;				
				//	printf("case I \t q1 %d_%d",i,j);
					}					
				}
			else if (phi[i][j]<=(1.0-0.5*(1.0/(tan(beta[i][j])))))
				{
//		----------------------------CASE III-------------------------------------
				ca[i][j]=4;
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					st[i][j]=phi[i][j]-0.5*(1.0/(tan(beta[i][j])));
					sb[i][j]=phi[i][j]+0.5*(1.0/(tan(beta[i][j])));
					sl[i][j]=0.0;
					sr[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
	
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]+0.5*dy;					
				
					x4[i]=x[i]+0.5*dx;
					y4[j]=y[j]-0.5*dy;				
				//	printf("case III \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{	
//					third quadrant
			 		sl[i][j]=phi[i][j]+0.5*(1.0/(tan(beta[i][j])));
					sr[i][j]=phi[i][j]-0.5*(1.0/(tan(beta[i][j])));
					st[i][j]=0.0;
					sb[i][j]=1.0;
					
					x1_int[i]=x[i]-0.5*dx;
					y1_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sr[i][j]*dy;

					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]-0.5*dy;					
				
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]-0.5*dy;				

				//	printf("case III \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					st[i][j]=phi[i][j]+0.5*(1.0/(tan(beta[i][j])));
					sb[i][j]=phi[i][j]-0.5*(1.0/(tan(beta[i][j])));
					sl[i][j]=1.0;
					sr[i][j]=0.0;
					x1_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;

					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]+0.5*dy;					
				
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]-0.5*dy;				

				//	printf("case III \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sl[i][j]=phi[i][j]-0.5*(1.0/(tan(beta[i][j])));
					sr[i][j]=phi[i][j]+0.5*(1.0/(tan(beta[i][j])));
					sb[i][j]=0.0;
					st[i][j]=1.0;
					x1_int[i]=x[i]-0.5*dx;
					y1_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
					
					x2_int[i]=x[i]+0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
		
					x3[i]=x[i]+0.5*dx;
					y3[j]=y[j]+0.5*dy;					
				
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]+0.5*dy;				

				//	printf("case III \t q1 %d_%d",i,j);
					}
				}
			else 	
				{
//		----------------------------CASE IV--------------------------------------
				ca[i][j]=5;
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					st[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sl[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sr[i][j]=1.0;
					sb[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;
					
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]-0.5*dy;
					
					x4[i]=x[i]+0.5*dx;
					y4[j]=y[j]-0.5*dy;
					
					x5[i]=x[i]+0.5*dx;
					y5[j]=y[j]+0.5*dy;
				//	printf("case IV \t q4 %d_%d",i,j);
					}	
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					sr[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					st[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sl[i][j]=1.0;
					sb[i][j]=1.0;
					x1_int[i]=x[i]+0.5*dx;
					y1_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
					
					x2_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y2_int[j]=y[j]+0.5*dy;
			
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]+0.5*dy;
					
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]-0.5*dy;
					
					x5[i]=x[i]+0.5*dx;
					y5[j]=y[j]-0.5*dy;
			
				//	printf("case IV \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					sb[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sr[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					st[i][j]=1.0;
					sl[i][j]=1.0; 
					x1_int[i]=x[i]+0.5*dx;
					y1_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
					
					x2_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y2_int[j]=y[j]-0.5*dy;
		
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]-0.5*dy;
					
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]+0.5*dy;
					
					x5[i]=x[i]+0.5*dx;
					y5[j]=y[j]+0.5*dy;
			
				//	printf("case IV \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					sl[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(1.0/(tan(beta[i][j]))));
					sb[i][j]=1.0-sqrt(2.0*(1.0-phi[i][j])*(tan(beta[i][j])));
					sr[i][j]=1.0;
					st[i][j]=1.0;					
					x1_int[i]=x[i]+0.5*dx-sb[i][j]*dx;
					y1_int[j]=y[j]-0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx;
					y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;
	
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]+0.5*dy;
					
					x4[i]=x[i]+0.5*dx;
					y4[j]=y[j]+0.5*dy;
					
					x5[i]=x[i]+0.5*dx;
					y5[j]=y[j]-0.5*dy;
			
				//	printf("case IV \t q1 %d_%d",i,j);
					}				
				}

			}			
//		----------------------------------zero normals calculations----------------------------------
	if(nr_x[i][j]==0.0 && nr_y[i][j]>0.0)
		{
			ca[i][j]=4;	
			sr[i][j]=phi[i][j];
			sl[i][j]=sr[i][j];
			st[i][j]=1.0;
			sb[i][j]=0.0;
			x1_int[i]=x[i]+0.5*dx;
			y1_int[j]=y[j]+0.5*dy-sr[i][j]*dy;
			
			x2_int[i]=x[i]-0.5*dx;
			y2_int[j]=y[j]+0.5*dy-sl[i][j]*dy;

			x3[i]=x[i]-0.5*dx;
			y3[j]=y[j]+0.5*dy;
					
			x4[i]=x[i]+0.5*dx;
			y4[j]=y[j]+0.5*dy;
				
		//	printf("nx=0 ny+ \t  %d_%d",i,j);	
		}else if(nr_x[i][j]==0.0 && nr_y[i][j]<0.0)
			{
			ca[i][j]=4;
				sr[i][j]=phi[i][j];
				sl[i][j]=sr[i][j];
				st[i][j]=0.0;
				sb[i][j]=1.0;
				x1_int[i]=x[i]+0.5*dx;
				y1_int[j]=y[j]-0.5*dy+sr[i][j]*dy;
				
				x2_int[i]=x[i]-0.5*dx;
				y2_int[j]=y[j]-0.5*dy+sl[i][j]*dy;	
	
				x3[i]=x[i]-0.5*dx;
				y3[j]=y[j]-0.5*dy;
					
				x4[i]=x[i]+0.5*dx;
				y4[j]=y[j]-0.5*dy;
				
		//		printf("nx=0 ny- \t  %d_%d",i,j);
			}else if(nr_y[i][j]==0.0 && nr_x[i][j]<0.0)
				{
					ca[i][j]=4;
					st[i][j]=phi[i][j];
					sb[i][j]=st[i][j];
					sr[i][j]=0.0;
					sl[i][j]=1.0;
					x1_int[i]=x[i]-0.5*dx+st[i][j]*dx;
					y1_int[j]=y[j]+0.5*dy;
					
					x2_int[i]=x[i]-0.5*dx+sb[i][j]*dx;
					y2_int[j]=y[j]-0.5*dy;	
		
					x3[i]=x[i]-0.5*dx;
					y3[j]=y[j]-0.5*dy;
					
					x4[i]=x[i]-0.5*dx;
					y4[j]=y[j]+0.5*dy;
		
		//			printf("ny=0 nx- \t  %d_%d",i,j);
				}else if(nr_y[i][j]==0.0 && nr_x[i][j]>0.0)
					{
					ca[i][j]=4;
						st[i][j]=phi[i][j];
						sb[i][j]=st[i][j];
						sr[i][j]=1.0;
						sl[i][j]=0.0;
						x1_int[i]=x[i]+0.5*dx-st[i][j]*dx;
						y1_int[j]=y[j]+0.5*dy;						
						
						x2_int[i]=x[i]+0.5*dx-sb[i][j]*dy;
						y2_int[j]=y[j]-0.5*dy;	
						
						x3[i]=x[i]+0.5*dx;
						y3[j]=y[j]-0.5*dy;
					
						x4[i]=x[i]+0.5*dx;
						y4[j]=y[j]+0.5*dy;
		//				printf("ny=0 nx+ \t  %d_%d",i,j);
					}
							
		}
//		-------------------------------Functions_for_fluxes-------------------------------------------//
//Case I
void xorig1r()//right
	{
		if(fabs(vel)*dt>=s2*l2)
			flx=phi[i][j]*dx*dy;
		else
			flx=0.5*fabs(vel)*dt*(2.0-fabs(vel)*dt/(s2*l2))*s1*l1;	
	}
void yorig1t()//top
	{
		if(fabs(vel)*dt<=(1.0-s1)*l1)
			flx=0.0;
		else
			flx=0.5*pow(fabs(vel)*dt-(1.0-s1)*l1,2.0)*gr;		
	}
void xorig1l()//left
	{
		if(fabs(vel)*dt<=(1.0-s2)*l2)
			flx=0.0;
		else
			flx=0.5*pow((fabs(vel)*dt-(1.0-s2)*l2),2.0)*gr;		
	}
void yorig1b()//bottom
	{
		if(fabs(vel)*dt>=s1*l1)
			flx=phi[i][j]*dx*dy;
		else
			flx=0.5*fabs(vel)*dt*(2.0-fabs(vel)*dt/(s1*l1))*s2*l2;	
	}
//Case II
void xorig2r()//right
	{
		flx=fabs(vel)*dt*(s1*l1-0.5*fabs(vel)*dt*gr);
	}
void yorig2t()
	{
		if(fabs(vel)*dt<=(1.0-s1)*l1)
			flx=0.0;
		else if(fabs(vel)*dt<=(1.0-s2)*l1)
			flx=0.5*pow(fabs(vel)*dt-(1.0-s1)*l1,2.0)*gr;
		else 
			flx=fabs(vel)*dt*l2-(1.0-phi[i][j])*dx*dy;		
	}
void xorig2l()
	{
		flx=fabs(vel)*dt*(s2*l1+0.5*fabs(vel)*dt*gr);	
	}
void yorig2b()
	{
		if(fabs(vel)*dt<=s2*l1)
			flx=fabs(vel)*dt*l2;
		else if(fabs(vel)*dt<=s1*l1)
			flx=fabs(vel)*dt*l2-0.5*pow(fabs(vel)*dt-s2*l1,2.0)*gr;
		else
			flx=phi[i][j]*dx*dy;		
	}
//Case III
void xorig3r()
	{
		if(fabs(vel)*dt<=s2*l1)
			flx=fabs(vel)*dt*l2;
		else if(fabs(vel)*dt<=s1*l1)
			flx=fabs(vel)*dt*l2-0.5*pow(fabs(vel)*dt-s2*l1,2.0)*gr;
		else 
			flx=phi[i][j]*dx*dy;			
	}
void yorig3t()
	{
		flx=fabs(vel)*dt*(s2*l1+0.5*fabs(vel)*dt*gr);	
	}
void xorig3l()
	{
		if(fabs(vel)*dt<=(1.0-s1)*l1)
			flx=0.0;
		else if(fabs(vel)*dt<=(1.0-s2)*l1)
			flx=0.5*pow((fabs(vel)*dt-(1.0-s1)*l1),2.0)*gr;
		else
			flx=fabs(vel)*dt*l2-(1.0-phi[i][j])*dx*dy;		
	}
void yorig3b()
	{
		flx=fabs(vel)*dt*(s1*l1-0.5*fabs(vel)*dt*gr);
	}
//Case IV
void xorig4r()
	{
		if(fabs(vel)*dt<=s2*l2)
			flx=fabs(vel)*dt*l1;
		else 
		flx=fabs(vel)*dt*l1-0.5*pow((fabs(vel)*dt-s2*l2),2.0)*gr;	
	}
void yorig4t()
	{
		if(fabs(vel)*dt>=(1.0-s1)*l1)
			flx=fabs(vel)*dt*l2-(1.0-phi[i][j])*dx*dy;
		else
			flx=fabs(vel)*dt*(s2*l2+0.5*fabs(vel)*dt*gr);	
	}
void xorig4l()
	{
		if(fabs(vel)*dt>=(1.0-s2)*l2)
			flx=fabs(vel)*dt*l1-(1.0-phi[i][j])*dx*dy;
		else
			flx=fabs(vel)*dt*(s1*l1+0.5*fabs(vel)*dt*gr);	
	}
void yorig4b()
	{
		if(fabs(vel)*dt<=s1*l1)
			flx=fabs(vel)*dt*l2;
		else
			flx=fabs(vel)*dt*l2-0.5*gr*pow(fabs(vel)*dt-s1*l1,2.0);	
	}
	
//		--------------------------------------Zero normals advection--------------------------------------
void nx0nypt()
	{
		if(fabs(vel)*dt<sr[i][j]*dy)
			flx=fabs(vel)*dt*dx;
		else
			flx=sr[i][j]*dy*dx;
	}
void nx0nypb()
	{
		if(fabs(vel)*dt<=(1.0-sr[i][j])*dy)
			flx=0.0;
		else
			flx=(fabs(vel)*dt-(1.0-sr[i][j])*dy)*dx;	
	}
void nx0nypr()
	{
			flx=fabs(vel)*dt*sr[i][j]*dy;
	}	
void nx0nypl()
	{
			flx=fabs(vel)*dt*sr[i][j]*dy;	
	}	
	
void nx0nynt()
	{
		if(fabs(vel)*dt<=(1.0-sr[i][j])*dy)
			flx=0.0;
		else
			flx=(fabs(vel)*dt-(1.0-sr[i][j])*dy)*dx;		
	}
void nx0nynb()
	{
		if(fabs(vel)*dt<(sr[i][j])*dy)
			flx=fabs(vel)*dt*dx;
		else
			flx=sr[i][j]*dy*dx;	
	}	
void nx0nynr()
	{
		flx=fabs(vel)*dt*sr[i][j]*dy;
	}
void nx0nynl()
	{
		flx=fabs(vel)*dt*sr[i][j]*dy;		
	}	
void ny0nxnr()
	{
		if(fabs(vel)*dt<(1.0-sb[i][j])*dx)
			flx=0.0;
		else
			flx=(fabs(vel)*dt-(1.0-sb[i][j])*dx)*dy;
	}	
void ny0nxnl()
	{
		if(fabs(vel)*dt<(sb[i][j])*dx)
			flx=fabs(vel)*dt*dy;
		else
			flx=sb[i][j]*dx*dy;
	}	
void ny0nxnt()
	{
		flx=fabs(vel)*dt*sb[i][j]*dx;		
	}	
void ny0nxnb()
	{
		flx=fabs(vel)*dt*sb[i][j]*dx;		
	}						
void ny0nxpr()
	{
		if(fabs(vel)*dt<sb[i][j]*dx)
			flx=fabs(vel)*dt*dy;
		else
			flx=sb[i][j]*dx*dy;
	}	
void ny0nxpl()
	{
		if(fabs(vel)*dt<=(1.0-sb[i][j])*dx)
			flx=0.0;
		else
			flx=(fabs(vel)*dt-(1.0-sb[i][j])*dx)*dy;
	}	
void ny0nxpt()
	{
		flx=fabs(vel)*dt*sb[i][j]*dx;	
	}	
void ny0nxpb()
	{
		flx=fabs(vel)*dt*sb[i][j]*dx;		
	}						

//________________________________________________________________Advection_churan___________________________________________		
void advect()
	{

// 		
//		-------------------Case Identification(Rudman Algorithm)feat. Shashwat_sir-----------------------//
	if(beta[i][j]<(M_PI/4.0))
		{
			
			if (phi[i][j]<=0.5*tan(beta[i][j]))
//		----------------------------------CASE I---------------------------------
				{
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//				fourth quadrant
				s1=sr[i][j];
				l1=dy;
				s2=sb[i][j];
				l2=dx;
				
				//right	
					if(ue>0.0)
					{	
					vel=ue;		
					xorig1r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;	
				//left
					if(uw<0.0)
					{
					vel=uw;
					gr=tan(alp[i][j]);
					xorig1l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
				//top
					if(vn>0.0)
					{
					vel=vn;
					gr=1.0/tan(alp[i][j]);
					yorig1t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(vs<0.0)
					{
					vel=vs;
					yorig1b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//printf("case I \t q4 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
				{
//				third quadrant
					s1=sb[i][j];
					l1=dx;
					s2=sl[i][j];
					l2=dy;
				//right
					if(ue>0.0)
					{
					vel=ue;
					gr=fabs(tan(alp[i][j]));
					yorig1t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(uw<0.0)
					{
					vel=uw;
					yorig1b();
					Fl[i][j]=flx;
					}else 
					Fl[i][j]=0.0;
				//top
					if(vn>0.0)
					{
					vel=vn;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig1l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(vs<0.0)
					{
					vel=vs;
					xorig1r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//printf("case I \t q3 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
				}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
				s1=sl[i][j];
				l1=dy;
				s2=st[i][j];
				l2=dx;
				//right
					if(ue>0.0)
					{
					vel=ue;
					gr=tan(alp[i][j]);
					xorig1l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(uw<0.0)
					{
					vel=uw;
					xorig1r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;	
				//top
					if(vn>0.0)
					{
					vel=vn;
					yorig1b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;	
				//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=(1.0/tan(alp[i][j]));
					yorig1t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
						
					//printf("case I \t q2 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
				s1=st[i][j];
				l1=dx;
				l2=dy;
				s2=sr[i][j];
				//right
					if(ue>0.0)
					{
					vel=ue;
					yorig1b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(uw<0.0)
					{
					vel=uw;
					gr=fabs(tan(alp[i][j]));
					yorig1t();
					Fl[i][j]=flx;
					}else 
					Fl[i][j]=0.0;
				//top
					if(vn>0.0)
					{
					vel=vn;
					xorig1r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig1l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case I \t q1 %d_%d",i,j);
					}					
			
				}
			else if(phi[i][j]<=(1.0-0.5*tan(beta[i][j])))	
				{
//		----------------------------------CASE II--------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					s1=sr[i][j];
					s2=sl[i][j];
					l1=dy;
					l2=dx;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=tan(alp[i][j]);
					xorig2r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=tan(alp[i][j]);
					xorig2l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=1.0/tan(alp[i][j]);
					yorig2t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=1.0/tan(alp[i][j]);
					yorig2b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case II \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					s1=sb[i][j];
					s2=st[i][j];
					l1=dx;
					l2=dy;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=fabs(tan(alp[i][j]));
					yorig2t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=fabs(tan(alp[i][j]));
					yorig2b();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig2l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig2r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
					
				//	printf("case II \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					s1=sl[i][j];
					s2=sr[i][j];
					l1=dy;
					l2=dx;
					//right
					if(ue>0.0)
					{		
					vel=ue;	
					gr=tan(alp[i][j]);
					xorig2l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=tan(alp[i][j]);
					xorig2r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=1.0/tan(alp[i][j]);		
					yorig2b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=1.0/tan(alp[i][j]);
					yorig2t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;	
				//	printf("case II \t q2 %d_%d",i,j);	
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					s1=st[i][j];
					s2=sb[i][j];
					l1=dx;
					l2=dy;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=fabs(tan(alp[i][j]));
					yorig2b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=fabs(tan(alp[i][j]));
					yorig2t();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig2r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig2l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;	
				//	printf("case II \t q1 %d_%d",i,j);	
					}
				}
			else 
				{
//		---------------------------------CASE IV---------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					s1=sl[i][j];
					s2=st[i][j];
					l1=dy;
					l2=dx;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=tan(alp[i][j]);
					xorig4r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=tan(alp[i][j]);
					xorig4l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=1.0/tan(alp[i][j]);
					yorig4t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=1.0/tan(alp[i][j]);
					yorig4b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q4 %d_%d",i,j);
				}	
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					s1=st[i][j];
					l1=dx;
					s2=sr[i][j];
					l2=dy;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=fabs(tan(alp[i][j]));
					yorig4t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=fabs(tan(alp[i][j]));
					yorig4b();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;	
				//	printf("case IV \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					s1=sr[i][j];
					l1=dy;
					s2=sb[i][j];
					l2=dx;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=tan(alp[i][j]);
					xorig4l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=tan(alp[i][j]);
					xorig4r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=1.0/tan(alp[i][j]);
					yorig4b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=1.0/tan(alp[i][j]);
					yorig4t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					s1=sb[i][j];
					l1=dx;
					s2=sl[i][j];
					l2=dy;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=fabs(tan(alp[i][j]));
					yorig4b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=fabs(tan(alp[i][j]));
					yorig4t();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;	
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q1 %d_%d",i,j);
					}
				}
		}
	else 
		{
			if(phi[i][j]<=0.5*(1.0/(tan(beta[i][j]))))
//		-------------------------------CASE I------------------------------------
				{
			if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//				fourth quadrant
				s1=sr[i][j];
				l1=dy;
				s2=sb[i][j];
				l2=dx;
				
				//right	
					if(ue>0.0)
					{	
					vel=ue;		
					xorig1r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;	
				
				//left
					if(uw<0.0)
					{
					vel=uw;
					gr=tan(alp[i][j]);
					xorig1l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
				
				//top
					if(vn>0.0)
					{
					vel=vn;
					gr=1.0/tan(alp[i][j]);
					yorig1t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(vs<0.0)
					{
					vel=vs;
					yorig1b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//printf("case I \t q4 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
				{
//				third quadrant
					s1=sb[i][j];
					l1=dx;
					s2=sl[i][j];
					l2=dy;
				//right
					if(ue>0.0)
					{
					vel=ue;
					gr=fabs(tan(alp[i][j]));
					yorig1t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(uw<0.0)
					{
					vel=uw;
					yorig1b();
					Fl[i][j]=flx;
					}else 
					Fl[i][j]=0.0;
				//top
					if(vn>0.0)
					{
					vel=vn;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig1l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(vs<0.0)
					{
					vel=vs;
					xorig1r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//printf("case I \t q3 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
				}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
				s1=sl[i][j];
				l1=dy;
				s2=st[i][j];
				l2=dx;
				//right
					if(ue>0.0)
					{
					vel=ue;
					gr=tan(alp[i][j]);
					xorig1l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(uw<0.0)
					{
					vel=uw;
					xorig1r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;	
				//top
					if(vn>0.0)
					{
					vel=vn;
					yorig1b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;	
				//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=(1.0/tan(alp[i][j]));
					yorig1t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
						
					//printf("case I \t q2 %d_%d\t%f\t%f\t%f\t%f\n",i,j,Fl[i][j],Fr[i][j],Ft[i][j],Fb[i][j]);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
				s1=st[i][j];
				l1=dx;
				l2=dy;
				s2=sr[i][j];
				//right
					if(ue>0.0)
					{
					vel=ue;
					yorig1b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
				//left
					if(uw<0.0)
					{
					vel=uw;
					gr=fabs(tan(alp[i][j]));
					yorig1t();
					Fl[i][j]=flx;
					}else 
					Fl[i][j]=0.0;
				//top
					if(vn>0.0)
					{
					vel=vn;
					xorig1r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
				//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig1l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case I \t q1 %d_%d",i,j);
					}										
			}
			else if (phi[i][j]<=(1.0-0.5*(1.0/(tan(beta[i][j])))))
				{
//		----------------------------CASE III-------------------------------------
				if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
				s1=sb[i][j];
				s2=st[i][j];
				l1=dx;
				l2=dy;
				//right
				if(ue>0.0)
				{
				vel=ue;
				gr=tan(alp[i][j]);
				xorig3r();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;
				//left
				if(uw<0.0)
				{
				vel=uw;
				gr=tan(alp[i][j]);
				xorig3l();
				Fl[i][j]=flx;
				}else
				Fl[i][j]=0.0;
				//top
				if(vn>0.0)
				{
				vel=vn;
				gr=1.0/tan(alp[i][j]);
				yorig3t();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(vs<0.0)
				{
				vel=vs;
				gr=1.0/tan(alp[i][j]);
				yorig3b();
				Fb[i][j]=flx;
				}else
				Fb[i][j]=0.0;
			//	printf("case III \t q4 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{	
//				third quadrant
				s1=sl[i][j];
				s2=sr[i][j];
				l1=dy;
				l2=dx;
				//right
				if(ue>0.0)
				{
				vel=ue;
				gr=fabs(tan(alp[i][j]));
				yorig3t();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;
				//left
				if(uw<0.0)
				{
				vel=uw;
				gr=fabs(tan(alp[i][j]));
				yorig3b();
				Fl[i][j]=flx;
				}else
				Fl[i][j]=0.0;
				//top
				if(vn>0.0)
				{
				vel=vn;
				gr=fabs(1.0/tan(alp[i][j]));
				xorig3l();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(vs<0.0)
				{
				vel=vs;
				gr=fabs(1.0/tan(alp[i][j]));
				xorig3r();
				Fb[i][j]=flx;	
				}else
				Fb[i][j]=0.0;
			//	printf("case III \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//				second quadrant
				s1=st[i][j];
				s2=sb[i][j];
				l1=dx;
				l2=dy;
				//right
				if(ue>0.0)
				{
				vel=ue;
				gr=tan(alp[i][j]);
				xorig3l();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;
				//left
				if(uw<0.0)
				{
				vel=uw;
				gr=tan(alp[i][j]);
				xorig3r();
				Fl[i][j]=flx;
				}else
				Fl[i][j]=0.0;
				//top
				if(vn>0.0)
				{
				vel=vn;
				gr=1.0/tan(alp[i][j]);
				yorig3b();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(vs<0.0)
				{
				vel=vs;
				gr=1.0/tan(alp[i][j]);
				yorig3t();
				Fb[i][j]=flx;
				}else
				Fb[i][j]=0.0;
				//	printf("case III \t q2 %d_%d",i,j);
				}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
				{
//				first quadrant
				s1=sr[i][j];
				s2=sl[i][j];
				l1=dy;
				l2=dx;
				//right
				if(ue>0.0)
				{
				vel=ue;
				gr=fabs(tan(alp[i][j]));
				yorig3b();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;	
				//left
				if(uw<0.0)
				{
				vel=uw;
				gr=fabs(tan(alp[i][j]));
				yorig3t();
				Fl[i][j]=flx;
				}else
				Fl[i][j]=0.0;
				//top
				if(vn>0.0)
				{
				vel=vn;
				gr=fabs(1.0/tan(alp[i][j]));
				xorig3r();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(vs<0.0)
				{
				vel=vs;
				gr=fabs(1.0/tan(alp[i][j]));
				xorig3l();
				Fb[i][j]=flx;	
				}else
				Fb[i][j]=0.0;	
			//	printf("case III \t q1 %d_%d",i,j);
					}
				}
			else 	
				{
//		----------------------------CASE IV--------------------------------------
		if(nr_x[i][j]>0.0 && nr_y[i][j]<0.0)
					{
//					fourth quadrant
					s1=sl[i][j];
					s2=st[i][j];
					l1=dy;
					l2=dx;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=tan(alp[i][j]);
					xorig4r();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=tan(alp[i][j]);
					xorig4l();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=1.0/tan(alp[i][j]);
					yorig4t();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=1.0/tan(alp[i][j]);
					yorig4b();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q4 %d_%d",i,j);
					}	
				else if(nr_x[i][j]<0.0 && nr_y[i][j]<0.0)
					{
//					third quadrant
					s1=st[i][j];
					l1=dx;
					s2=sr[i][j];
					l2=dy;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=fabs(tan(alp[i][j]));
					yorig4t();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=fabs(tan(alp[i][j]));
					yorig4b();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4l();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4r();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;	
				//	printf("case IV \t q3 %d_%d",i,j);
					}
				else if(nr_x[i][j]<0.0 && nr_y[i][j]>0.0)
					{
//					second quadrant
					s1=sr[i][j];
					l1=dy;
					s2=sb[i][j];
					l2=dx;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=tan(alp[i][j]);
					xorig4l();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=tan(alp[i][j]);
					xorig4r();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=1.0/tan(alp[i][j]);
					yorig4b();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=1.0/tan(alp[i][j]);
					yorig4t();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q2 %d_%d",i,j);
					}
				else if(nr_x[i][j]>0.0 && nr_y[i][j]>0.0)
					{
//					first quadrant
					s1=sb[i][j];
					l1=dx;
					s2=sl[i][j];
					l2=dy;
					//right
					if(ue>0.0)
					{
					vel=ue;
					gr=fabs(tan(alp[i][j]));
					yorig4b();
					Fr[i][j]=flx;
					}else
					Fr[i][j]=0.0;
					//left
					if(uw<0.0)
					{
					vel=uw;
					gr=fabs(tan(alp[i][j]));
					yorig4t();
					Fl[i][j]=flx;
					}else
					Fl[i][j]=0.0;	
					//top
					if(vn>0.0)
					{
					vel=vn;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4r();
					Ft[i][j]=flx;
					}else
					Ft[i][j]=0.0;
					//bottom
					if(vs<0.0)
					{
					vel=vs;
					gr=fabs(1.0/tan(alp[i][j]));
					xorig4l();
					Fb[i][j]=flx;
					}else
					Fb[i][j]=0.0;
				//	printf("case IV \t q1 %d_%d",i,j);
					}
				}
			}			
//		----------------------------------zero normals calculations----------------------------------
	if(nr_x[i][j]==0.0 && nr_y[i][j]>0.0)
		{
		//top
		if(vn>0.0)
		{
		vel=vn;
		nx0nypt();
		Ft[i][j]=flx;		
		}else
		Ft[i][j]=0.0;
		//bottom
		if(vs<0.0)
		{
		vel=vs;
		nx0nypb();
		Fb[i][j]=flx;
		}else
		Fb[i][j]=0.0;
		//right
		if(ue>0.0)
		{
		vel=ue;
		nx0nypr();
		Fr[i][j]=flx;
		}else
		Fr[i][j]=0.0;	
	
		//left
		if(uw<0.0)
		{
		vel=uw;
		nx0nypl();
		Fl[i][j]=flx;
		}else
		Fl[i][j]=0.0;
		//	printf("nx=0 ny+ \t  %d_%d",i,j);	
		}else if(nr_x[i][j]==0.0 && nr_y[i][j]<0.0)
			{
				//top
				if(vn>0.0)
				{
				vel=vn;
				nx0nynt();
				Ft[i][j]=flx;
				}else
				Ft[i][j]=0.0;
				//bottom
				if(vs<0.0)
				{
				vel=vs;
				nx0nynb();
				Fb[i][j]=flx;	
				}else
				Fb[i][j]=0.0;
				//right
				if(ue>0.0)
				{
				vel=ue;
				nx0nynr();
				Fr[i][j]=flx;
				}else
				Fr[i][j]=0.0;
				//left
				if(uw<0.0)
				{
				vel=uw;
				nx0nynl();
				Fl[i][j]=flx;	
				}else
				Fl[i][j]=0.0;	
		//		printf("nx=0 ny- \t  %d_%d",i,j);
			}else if(nr_y[i][j]==0.0 && nr_x[i][j]<0.0)
				{
						//right
						if(ue>0.0)
						{
						vel=ue;
						ny0nxnr();
						Fr[i][j]=flx;
						}else
						Fr[i][j]=0.0;	
						//left
						if(uw<0.0)
						{
						vel=uw;
						ny0nxnl();
						Fl[i][j]=flx;	
						}else
						Fl[i][j]=0.0;
						//top
						if(vn>0.0)
						{
						vel=vn;
						ny0nxnt();
						Ft[i][j]=flx;
						}else
						Ft[i][j]=0.0;	
						//bottom
						if(vs<0.0)
						{
						vel=vs;
						ny0nxnb();
						Fb[i][j]=flx;
						}else
						Fb[i][j]=0.0;						
		//			printf("ny=0 nx- \t  %d_%d",i,j);
				}else if(nr_y[i][j]==0.0 && nr_x[i][j]>0.0)
					{
						//right
						if(ue>0.0)
						{
						vel=ue;
						ny0nxpr();
						Fr[i][j]=flx;
						}else
						Fr[i][j]=0.0;
						//left
						if(uw<0.0)
						{
						vel=uw;
						ny0nxpl();
						Fl[i][j]=flx;
						}else
						Fl[i][j]=0.0;
						//top
						if(vn>0.0)
						{
						vel=vn;
						ny0nxpt();
						Ft[i][j]=flx;
						}else
						Ft[i][j]=0.0;				
						//bottom
						if(vs<0.0)
						{
						vel=vs;
						ny0nxpb();
						Fb[i][j]=flx;
						}else
						Fb[i][j]=0.0;						
		//				printf("ny=0 nx+ \t  %d_%d",i,j);
					}
					
	}
// 		First order upwinding routine	
void FOU()
	{
				if(uw>0.0)
				{
					uwa=u[i-1][j];
					vwa=v[i-1][j];
				}else
					{
						uwa=u[i][j];
						vwa=v[i][j];
					}
				if(ue>0.0)
				{
					uea=u[i][j];
					vea=v[i][j];
				}else
					{
						uea=u[i+1][j];
						vea=v[i+1][j];
					}
				if(vn>0.0)
				{
					una=u[i][j];
					vna=v[i][j];
				}else
					{
						una=u[i][j+1];
						vna=v[i][j+1];
					}
				if(vs>0.0)
				{
					usa=u[i][j-1];
					vsa=v[i][j-1];
				}else
					{
						usa=u[i][j];
						vsa=v[i][j];
					}
			
	}
	

// 		Quadratic upstream interpolation for convective kinematics with estimated streaming terms (Lax_Wendroff) routine	
void Lax_Wendroff()
	{
				cw=uw*dt/dx;
				ce=ue*dt/dx;
				cn=vn*dt/dy;
				cs=vs*dt/dy;
				
				if(uw>0.0)
				{
					uwaq=0.5*(u[i][j]+u[i-1][j]-cw*(u[i][j]-u[i-1][j]));
					vwaq=0.5*(v[i][j]+v[i-1][j]-cw*(v[i][j]-v[i-1][j]));
				}else
					{
						uwaq=0.5*(u[i][j]+u[i-1][j]-cw*(u[i-1][j]-u[i][j]));
						vwaq=0.5*(v[i][j]+v[i-1][j]-cw*(v[i-1][j]-v[i][j]));
					}
				if(ue>0.0)
				{
					ueaq=0.5*(u[i][j]+u[i+1][j]-ce*(u[i+1][j]-u[i][j]));
					veaq=0.5*(v[i][j]+v[i+1][j]-ce*(v[i+1][j]-v[i][j]));
				}else
					{
						ueaq=0.5*(u[i][j]+u[i+1][j]-ce*(u[i][j]-u[i+1][j]));
						veaq=0.5*(v[i][j]+v[i+1][j]-ce*(v[i][j]-v[i+1][j]));
					}
				if(vn>0.0)
				{
					unaq=0.5*(u[i][j]+u[i][j+1]-cn*(u[i][j+1]-u[i][j]));
					vnaq=0.5*(v[i][j]+v[i][j+1]-cn*(v[i][j+1]-v[i][j]));
				}else
					{
						unaq=0.5*(u[i][j]+u[i][j+1]-cn*(u[i][j]-u[i][j+1]));
						vnaq=0.5*(v[i][j]+v[i][j+1]-cn*(v[i][j]-v[i][j+1]));
					}
				if(vs>0.0)
				{
						usaq=0.5*(u[i][j]+u[i][j-1]-cs*(u[i][j]-u[i][j-1]));
						vsaq=0.5*(v[i][j]+v[i][j-1]-cs*(v[i][j]-v[i][j-1]));
				}else
					{
						usaq=0.5*(u[i][j]+u[i][j-1]-cs*(u[i][j-1]-u[i][j]));
						vsaq=0.5*(v[i][j]+v[i][j-1]-cs*(v[i][j-1]-v[i][j]));
					}
			
	}	
void QUICK()
	{
	
				if(uw>0.0)
				{
					uwaq=(3.0/8.0)*u[i][j]+(3.0/4.0)*u[i-1][j]-(1.0/8.0)*u[i-2][j];
					vwaq=(3.0/8.0)*v[i][j]+(3.0/4.0)*v[i-1][j]-(1.0/8.0)*v[i-2][j];
				}else
					{
						uwaq=(3.0/8.0)*u[i-1][j]+(3.0/4.0)*u[i][j]-(1.0/8.0)*u[i+1][j];
						vwaq=(3.0/8.0)*v[i-1][j]+(3.0/4.0)*v[i][j]-(1.0/8.0)*v[i+1][j];
					}
				if(ue>0.0)
				{
					ueaq=(3.0/8.0)*u[i+1][j]+(3.0/4.0)*u[i][j]-(1.0/8.0)*u[i-1][j];
					veaq=(3.0/8.0)*v[i+1][j]+(3.0/4.0)*v[i][j]-(1.0/8.0)*v[i-1][j];
				}else
					{
						ueaq=(3.0/8.0)*u[i][j]+(3.0/4.0)*u[i+1][j]-(1.0/8.0)*u[i+2][j];
						veaq=(3.0/8.0)*v[i][j]+(3.0/4.0)*v[i+1][j]-(1.0/8.0)*v[i+2][j];
					}
				if(vn>0.0)
				{
					unaq=(3.0/8.0)*u[i][j+1]+(3.0/4.0)*u[i][j]-(1.0/8.0)*u[i][j-1];
					vnaq=(3.0/8.0)*v[i][j+1]+(3.0/4.0)*v[i][j]-(1.0/8.0)*v[i][j-1];
					
				}else
					{
						unaq=(3.0/8.0)*u[i][j]+(3.0/4.0)*u[i][j+1]-(1.0/8.0)*u[i][j+2];
						vnaq=(3.0/8.0)*v[i][j]+(3.0/4.0)*v[i][j+1]-(1.0/8.0)*v[i][j+2];
					}
				if(vs>0.0)
				{
					usaq=(3.0/8.0)*u[i][j]+(3.0/4.0)*u[i][j-1]-(1.0/8.0)*u[i][j-2];
					vsaq=(3.0/8.0)*v[i][j]+(3.0/4.0)*v[i][j-1]-(1.0/8.0)*v[i][j-2];
					
				}else
					{
						usaq=(3.0/8.0)*u[i][j-1]+(3.0/4.0)*u[i][j]-(1.0/8.0)*u[i][j+1];
						vsaq=(3.0/8.0)*v[i][j-1]+(3.0/4.0)*v[i][j]-(1.0/8.0)*v[i][j+1];
					}
		
	}	


// 		Flux limiter for dealing with low precision of Lax_Wendroff and low resolution of FOU	
void superbee()
	{
			
				FOU();
				if(order==3)
				QUICK();
				else if(order==2)
				Lax_Wendroff();
				// face slope value calculation
			
				if(ue>0.0)
				slope_ueh=(u[i][j]-u[i-1][j])/(u[i+1][j]-u[i][j]);
				else 
				slope_ueh=(u[i+2][j]-u[i+1][j])/(u[i+1][j]-u[i][j]);
				if(uw>0.0)
				slope_uwh=(u[i-1][j]-u[i-2][j])/(u[i][j]-u[i-1][j]);
				else
				slope_uwh=(u[i+1][j]-u[i][j])/(u[i][j]-u[i-1][j]);
				if(vn>0.0)
				slope_unv=(u[i][j]-u[i][j-1])/(u[i][j+1]-u[i][j]);
				else
				slope_unv=(u[i][j+2]-u[i][j+1])/(u[i][j+1]-u[i][j]);
				if(vs>0.0)
				slope_usv=(u[i][j-1]-u[i][j-2])/(u[i][j]-u[i][j-1]);
				else
				slope_usv=(u[i][j+1]-u[i][j])/(u[i][j]-u[i][j-1]);

				if(ue>0.0)
				slope_veh=(v[i][j]-v[i-1][j])/(v[i+1][j]-v[i][j]);
				else 
				slope_veh=(v[i+2][j]-v[i+1][j])/(v[i+1][j]-v[i][j]);
				if(uw>0.0)
				slope_vwh=(v[i-1][j]-v[i-2][j])/(v[i][j]-v[i-1][j]);
				else
				slope_vwh=(v[i+1][j]-v[i][j])/(v[i][j]-v[i-1][j]);
				if(vn>0.0)
				slope_vnv=(v[i][j]-v[i][j-1])/(v[i][j+1]-v[i][j]);
				else
				slope_vnv=(v[i][j+2]-v[i][j+1])/(v[i][j+1]-v[i][j]);
				if(vs>0.0)
				slope_vsv=(v[i][j-1]-v[i][j-2])/(v[i][j]-v[i][j-1]);
				else
				slope_vsv=(v[i][j+1]-v[i][j])/(v[i][j]-v[i][j-1]);

//				 finding minimum inside limiter(uw)
				if(2.0*slope_uwh<1.0)
					a1=2.0*slope_uwh;
				else
					a1=1.0;	
				
				if(slope_uwh<2.0)
					a2=slope_uwh;
				else
					a2=2.0;	
				
				//Finding maximum amongst
				if(a1>0.0 && a1>a2)
					lim_uw=a1;
				else if(a2>0.0 && a2>a1)
					lim_uw=a2;
				else
					lim_uw=0.0;	 
				
//				 finding minimum inside limiter(vw)
				if(2.0*slope_vwh<1.0)
					a3=2.0*slope_vwh;
				else
					a3=1.0;	
				
				if(slope_vwh<2.0)
					a4=slope_vwh;
				else
					a4=2.0;	
				
				//Finding maximum amongst
				if(a3>0.0 && a3>a4)
					lim_vw=a3;
				else if(a4>0.0 && a4>a3)
					lim_vw=a4;
				else
					lim_vw=0.0;	 

//				 finding minimum inside limiter(ue)
				if(2.0*slope_ueh<1.0)
					a11=2.0*slope_ueh;
				else
					a11=1.0;	
				
				if(slope_ueh<2.0)
					a22=slope_ueh;
				else
					a22=2.0;	
				
				//Finding maximum amongst
				if(a11>0.0 && a11>a22)
					lim_ue=a11;
				else if(a22>0.0 && a22>a11)
					lim_ue=a22;
				else
					lim_ue=0.0;	 
				
//				 finding minimum inside limiter(ve)
				if(2.0*slope_veh<1.0)
					a33=2.0*slope_veh;
				else
					a33=1.0;	
				
				if(slope_veh<2.0)
					a44=slope_veh;
				else
					a44=2.0;	
				
				//Finding maximum amongst
				if(a33>0.0 && a33>a44)
					lim_ve=a33;
				else if(a44>0.0 && a44>a33)
					lim_ve=a44;
				else
					lim_ve=0.0;	 				
				
//				 finding minimum inside limiter(un)
				if(2.0*slope_unv<1.0)
					a5=2.0*slope_unv;
				else
					a5=1.0;	
				
				if(slope_unv<2.0)
					a6=slope_unv;
				else
					a6=2.0;	
				
				//Finding maximum amongst
				if(a5>0.0 && a5>a6)
					lim_un=a5;
				else if(a6>0.0 && a6>a5)
					lim_un=a6;
				else
					lim_un=0.0;	 
				
//				 finding minimum inside limiter(vn)
				if(2.0*slope_vnv<1.0)
					a7=2.0*slope_vnv;
				else
					a7=1.0;	
				
				if(slope_vnv<2.0)
					a8=slope_vnv;
				else
					a8=2.0;	
				
				//Finding maximum amongst
				if(a7>0.0 && a7>a8)
					lim_vn=a7;
				else if(a8>0.0 && a8>a7)
					lim_vn=a8;
				else
					lim_vn=0.0;	 
					
//				 finding minimum inside limiter(us)
				if(2.0*slope_usv<1.0)
					a55=2.0*slope_usv;
				else
					a55=1.0;	
				
				if(slope_usv<2.0)
					a66=slope_usv;
				else
					a66=2.0;	
				
				//Finding maximum amongst
				if(a55>0.0 && a55>a66)
					lim_us=a55;
				else if(a66>0.0 && a66>a55)
					lim_us=a66;
				else
					lim_us=0.0;	 
				
//				 finding minimum inside limiter(vs)
				if(2.0*slope_vsv<1.0)
					a77=2.0*slope_vsv;
				else
					a77=1.0;	
				
				if(slope_vsv<2.0)
					a88=slope_vsv;
				else
					a88=2.0;	
				
				//Finding maximum amongst
				if(a77>0.0 && a77>a88)
					lim_vs=a77;
				else if(a88>0.0 && a88>a77)
					lim_vs=a88;
				else
					lim_vs=0.0;	 		
//		-------------------------------------------------------------					
				// advected fluxes
				uwl=uwa-lim_uw*(uwa-uwaq);
				vwl=vwa-lim_vw*(vwa-vwaq);
				
				uel=uea-lim_ue*(uea-ueaq);
				v_el=vea-lim_ve*(vea-veaq);
		
				unl=una-lim_un*(una-unaq);
				vnl=vna-lim_vn*(vna-vnaq);
					
				usl=usa-lim_us*(usa-usaq);
				vsl=vsa-lim_vs*(vsa-vsaq);	
	}	
	
