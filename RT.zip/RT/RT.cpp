//		--------------------------------Rayleigh_Taylor_Instability(Geurmond_Quatrapelle)--------------------------------------------//
//		
//		_______________________________________________________________________________________________________//
#include<stdio.h>
#include<math.h>
#include"functions.h"

main()
{
//		--------------------------------domain and essentials--------------------------------------//
L=1.0;
H=3.0;
nx=40;
ny=120;
dx=L/nx;
dy=H/ny;
x_centre=L/2.0;
y_centre=2.0*H/3.0;
//R=0.15;
dt=0.001;
Re=500.0;
Froude=0.5;
u0=1.0;
//Two fluid property
rho1=1.2;
rho2=1.0;
visc1=1.0;//not needed to be declared
visc2=visc1;
rel_fac=1.0;//relaxation factor
//		----------------------------------PLIC Grid-----------------------------------------------//
xp[1]=0.0;
for(i=2;i<=nx+1;i++)
	xp[i]=xp[i-1]+dx;
yp[1]=0.0;
for(j=2;j<=ny+1;j++)
	yp[j]=yp[j-1]+dy;
//		--------------------------------------FVM Grid--------------------------------------------//
x[1]=0.5*dx;
for(i=2;i<=nx;i++)
	x[i]=x[i-1]+dx;

y[1]=0.5*dy;
for(j=2;j<=ny;j++)
	y[j]=y[j-1]+dy;

//		----------------------------------Initialization-------------------------------------------
for(i=0;i<=nx+1;i++)
    {
    for(j=0;j<=ny+1;j++)
        {
       		u[i][j]=0.0;
       		v[i][j]=0.0;
       		ut[i][j]=0.0;
       		vt[i][j]=0.0;
       		p[i][j]=0.0;
       		pc[i][j]=0.0;
       		Res=0.0;
       		corr=0.0;
	    }
    }
//		-------------------------------------Patching-intializing---------------------------------//
float xt,yt,dmx,dmy;
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			count=0;
			cv();
			for(n=1;n<=4;n++)
				{
				//---------------------------RT purtabation--------------------------------------------
				(yv[n])-0.02*cos(M_PI*(1.0+xv[n]))-2.0>=0.0?count++:0;
				}
				if(count==4)
				phi[i][j]=1.0;
				else if(count==0)
				phi[i][j]=0.0;
			else
			{
				int mx=300,my=300;
				dmx=dx/mx;
				dmy=dy/my;
				count=0;
					for(n=1;n<=mx;n++)
						{
						for(q=1;q<=my;q++)
							{
							xt=xv[1]+(n-0.5)*dmx;
							yt=yv[1]+(q-0.5)*dmy;
				//-----------------------------RT Perturbation-----------------------------------------
					(yt)+0.02*cos(M_PI*(1.0+xt))-2.0>=0.0?count++:0;
					 		}
						}
				phi[i][j]=(count*1.0)/(mx*my); //total vol. fraction in cell [i,j]=No.of cells inside/total cells in cell [i,j]

			}
		}
	}
tc=0;
rcnst_count=0;
do
{
//		---------------------------------Solving_Phi_equation-----------------------------------------------
FILE *f2;
f2=fopen("fluid_polygon.dat","w");
FILE *f3;
f3=fopen("rcnst.dat","w");

//wall Boundary conditions
	for(i=1;i<=nx;i++)
		{
			phi[i][0]=phi[i][1];
			phi[i][ny+1]=phi[i][ny];

			u[i][0]=-u[i][1];     //Bottom Wall
			u[i][ny+1]=-u[i][ny]; //Top Wall
			v[i][0]=-v[i][1];     //Bottom Wall
			v[i][ny+1]=-v[i][ny]; // Top Wall
		}
//Symmetry Boundary conditions
	for(j=1;j<=ny;j++)
		{
			phi[0][j]=phi[1][j];
			phi[nx+1][j]=phi[nx][j];

			u[0][j]=-u[1][j];      //Left Symmetry (Normal Velocity to the plane is zero)
			u[nx+1][j]=-u[nx][j];  //Right Symmetry (Normal Velocity to the plane is zero)
			v[0][j]=v[1][j];      //Left Symmetry (Normal gradients at the plane are zero)
			v[nx+1][j]=-v[nx][j];  //Right Symmetry (Normal gradients at the plane are zero)
		}

for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			//Face velocities
			fvel();

			if(phi[i][j]<=(1.0+eps) && phi[i][j]>=(1.0-eps))//pure water
				{
					pure_water();
					fprintf(f2,"%f\t%f\n",xp[i],yp[j]);			 				     
					fprintf(f2,"%f\t%f\n",xp[i+1],yp[j]);
					fprintf(f2,"%f\t%f\n",xp[i+1],yp[j+1]);
					fprintf(f2,"%f\t%f\n",xp[i],yp[j+1]);
					fprintf(f2,"%f\t%f\n\n",xp[i],yp[j]);			 					     
			
				}
			else if (phi[i][j]>eps && phi[i][j]<(1.0-eps))//mixed cells
				{
//		--------------------------------------Reconstruction----------------------------------------------
					rcnst();
					fprintf(f3,"%f\t%f\n%f\t%f\n\n",x1_int[i],y1_int[j],x2_int[i],y2_int[j]);
					fprintf(f2,"%f\t%f\n%f\t%f\n\n",x1_int[i],y1_int[j],x2_int[i],y2_int[j]);
					if(ca[i][j]==3)
					{
						fprintf(f2,"%f\t%f\n",x3[i],y3[j]);
						fprintf(f2,"%f\t%f\n\n",x1_int[i],y1_int[j]);			 
					}else if(ca[i][j]==4)
						{
							fprintf(f2,"%f\t%f\n",x3[i],y3[j]);
							fprintf(f2,"%f\t%f\n",x4[i],y4[j]);
							fprintf(f2,"%f\t%f\n\n",x1_int[i],y1_int[j]);			 
						}else if(ca[i][j]=5)
							{
								fprintf(f2,"%f\t%f\n",x3[i],y3[j]);
								fprintf(f2,"%f\t%f\n",x4[i],y4[j]);
								fprintf(f2,"%f\t%f\n",x5[i],y5[j]);	
								fprintf(f2,"%f\t%f\n\n",x1_int[i],y1_int[j]);			 
							}
//		-------------------------------------Flux Calculation----------------------------------
					advect();
				}//else-if for interface detection closure
			else//pure air
				{
					Fr[i][j]=0.0;
					Fl[i][j]=0.0;
					Ft[i][j]=0.0;
					Fb[i][j]=0.0;
				}
		}//For loop closure
	}//For loop closure
rcnst_count++;
//		-------------------------------------X-advection--------------------------------------------------
double sumx=0.0;
for (i=1;i<=nx;i++)
	{
	for (j=1;j<=ny;j++)
		{

				//free slip BC in fluxes
				Fr[0][j]=0.0;
			//	Fl[0][j]=0.0;
				Fl[1][j]=0.0;
				Ft[0][j]=Ft[1][j];
				Fb[0][j]=Fb[1][j];
				Fl[nx+1][j]=0.0;
				Fr[nx][j]=0.0;
				Ft[nx+1][j]=Ft[nx][j];
				Fb[nx+1][j]=Fb[nx][j];
			//	Fr[nx+1][j]=0.0;
				//Wall boundary conditions for the wall fluxes
				//Top wall
				Ft[i][ny]=0.0;
				Fr[i][ny+1]=Fr[i][ny];
				Fl[i][ny+1]=Fl[i][ny];
				Fb[i][ny+1]=0.0;
				Ft[i][ny+1]=0.0;
				//Bottom wall
				Fb[i][1]=0.0;
				Fr[i][0]=Fr[i][1];
				Fl[i][0]=Fl[i][1];
				Ft[i][0]=0.0;
				Fb[i][0]=0.0;
				//Face velocities
				fvel();

				// with Dilatation
				phi_t[i][j]=(phi[i][j]+(1.0/(dx*dy))*(-Fl[i][j]-Fr[i][j]+Fr[i-1][j]+Fl[i+1][j]))/(1.0-(ue-uw)*dt/dx);

				//Truncation of Overshoot and Undershoot (reco by Shashwat sir)
				if(phi_t[i][j]>(1+eps1)) // Overshoot
					phi_t[i][j]=1.0;
				else if(phi_t[i][j]<-eps1) //Undershoot
					phi_t[i][j]=0.0;

				phi[i][j]=phi_t[i][j];
				sumx=sumx+phi[i][j]*dx*dy;
		//		fprintf(f2,"%f\t%f\n%f\n",x[i],y[j],phi[i][j]);
		}
	}

for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			//Face velocities
			fvel();

			if(phi[i][j]<=(1.0+eps) && phi[i][j]>=(1.0-eps))//pure water
				{
					pure_water();
				}
			else if (phi[i][j]>eps && phi[i][j]<(1.0-eps))//mixed cells
				{
//		--------------------------------------Reconstruction----------------------------------------------
					rcnst();
				//	fprintf(f2,"%f\t%f\n%f\t%f\n\n",x1_int[i],y1_int[j],x2_int[i],y2_int[j]);
//		--------------------------------------Flux Calculations-------------------------------------------
					advect();
				}//else-if for interface detection closure
			else//pure air
				{
					Fr[i][j]=0.0;
					Fl[i][j]=0.0;
					Ft[i][j]=0.0;
					Fb[i][j]=0.0;
				}
		}//For loop closure
	}//For loop closure
rcnst_count++;
double sumy=0.0;
//		---------------------------------------Y-advection-----------------------------------------------
for (i=1;i<=nx;i++)
	{
	for (j=1;j<=ny;j++)
		{

				//free slip BC in fluxes
				Fr[0][j]=0.0;
			//	Fl[0][j]=0.0;
				Fl[1][j]=0.0;
				Ft[0][j]=Ft[1][j];
				Fb[0][j]=Fb[1][j];
				Fl[nx+1][j]=0.0;
				Fr[nx][j]=0.0;
				Ft[nx+1][j]=Ft[nx][j];
				Fb[nx+1][j]=Fb[nx][j];
			//	Fr[nx+1][j]=0.0;
				//Wall boundary conditions for the wall fluxes
				//Top wall
				Ft[i][ny]=0.0;
				Fr[i][ny+1]=Fr[i][ny];
				Fl[i][ny+1]=Fl[i][ny];
				Fb[i][ny+1]=0.0;
				Ft[i][ny+1]=0.0;
				//Bottom wall
				Fb[i][1]=0.0;
				Fr[i][0]=Fr[i][1];
				Fl[i][0]=Fl[i][1];
				Ft[i][0]=0.0;
				Fb[i][0]=0.0;

				//Face velocities
				fvel();
				// with Dilatation
				phinew[i][j]=phi_t[i][j]*(1.0+(vn-vs)*dt/dy)+(1.0/(dx*dy))*(-Fb[i][j]-Ft[i][j]+Fb[i][j+1]+Ft[i][j-1]);

				//Truncation of overshoot and undershoot (reco by Shashwat sir)
				if(phinew[i][j]>(1+eps1)) //Overshoot
					phinew[i][j]=1.0;
				else if(phinew[i][j]<-eps1) //Undershoot
					phinew[i][j]=0.0;

				phi[i][j]=phinew[i][j];
				sumy=sumy+phi[i][j]*dx*dy;
		//		fprintf(f2,"%f\t%f\n%f\n",x[i],y[j],phi[i][j]);
		}
	}
//		---------------------------------------Density and Viscosity Calculations-----------------------//
for (i=1;i<=nx;i++)
	{
	for (j=1;j<=ny;j++)
		{
			rho[i][j]=phi[i][j]+(1.0-phi[i][j])*rho2/rho1;
			visc[i][j]=phi[i][j]+(1.0-phi[i][j])*visc2/visc1;
		//	printf("rho=%f\n",rho[i][j]);
		}
	}
//		__________________________________________________________________________________________________
//		----------------------------------------N-S__Solver---------------------------------------------//
//		___________________________________________||_____________________________________________________
sum=0.0;
//wall Boundary conditions
	for(i=1;i<=nx;i++)
		{
			u[i][0]=-u[i][1];     //Bottom Wall
			u[i][ny+1]=-u[i][ny]; //Top Wall
			v[i][0]=-v[i][1];     //Bottom Wall
			v[i][ny+1]=-v[i][ny]; // Top Wall
		}
//Symmetry Boundary conditions
	for(j=1;j<=ny;j++)
		{
			u[0][j]=-u[1][j];      //Left Symmetry (Normal Velocity to the plane is zero)
			u[nx+1][j]=-u[nx][j];  //Right Symmetry (Normal Velocity to the plane is zero)
			v[0][j]=v[1][j];      //Left Symmetry (Normal gradients at the plane are zero)
			v[nx+1][j]=-v[nx][j];  //Right Symmetry (Normal gradients at the plane are zero)
		}

	for(i=1;i<=nx;i++)
		{
		for(j=1;j<=ny;j++)
			{
				//face velocities
				fvel();
				
				//FOU Routine
				if(uw>0.0)
				{
					uwa=u[i-1][j];
					vwa=v[i-1][j];
				}else
					{
						uwa=u[i][j];
						vwa=v[i][j];
					}
				if(ue>0.0)
				{
					uea=u[i][j];
					vea=v[i][j];
				}else
					{
						uea=u[i+1][j];
						vea=v[i+1][j];
					}
				if(vn>0.0)
				{
					una=u[i][j];
					vna=v[i][j];
				}else
					{
						una=u[i][j+1];
						vna=v[i][j+1];
					}
				if(vs>0.0)
				{
					usa=u[i][j-1];
					vsa=v[i][j-1];
				}else
					{
						usa=u[i][j];
						vsa=v[i][j];
					}
				//Face viscosity
				fvisc();
				fvel();

				aw=dy/dx;
				ae=aw;
				as=dx/dy;
				an=as;
				ap=-(ae*visce+aw*viscw+an*viscn+as*viscs);
//		------------------------------------TILDE VELOCITY----------------------------------------------
				fxad=(dt/dx)*(uwa*uw-uea*ue)+(dt/dy)*(usa*vs-una*vn);
				fxdf=(dt*visc[i][j]/(dx*dy*Re*rho[i][j]))*(aw*viscw*u[i-1][j]+ae*visce*u[i+1][j]+as*viscs*u[i][j-1]+an*viscn*u[i][j+1]);
				ut[i][j]=u[i][j]*(1.0+ap*dt*visc[i][j]/(Re*dx*dy*rho[i][j]))+fxad+fxdf;

				fyad=(dt/dx)*(vwa*uw-vea*ue)+(dt/dy)*(vsa*vs-vna*vn);
				fydf=(dt*visc[i][j]/(dx*dy*Re*rho[i][j]))*(aw*viscw*v[i-1][j]+ae*visce*v[i+1][j]+as*viscs*v[i][j-1]+an*viscn*v[i][j+1]);
				vt[i][j]=v[i][j]*(1.0+ap*dt*visc[i][j]/(Re*rho[i][j]*dx*dy))+fyad+fydf-(dt/(Froude*Froude));
			}
		}
//		----------------------Boundary conditions for tilde velocity and old pressure-------------------
	for(i=1;i<=nx;i++)
		{
			ut[i][0]=-ut[i][1];
			ut[i][ny+1]=-ut[i][ny];
			vt[i][0]=-vt[i][1];
			vt[i][ny+1]=-vt[i][ny];
			p[i][ny+1]=p[i][ny];
			p[i][0]=p[i][1];
		}
	for(j=1;j<=ny;j++)
		{
			ut[0][j]=-ut[1][j];
			ut[nx+1][j]=-ut[nx][j];
			vt[0][j]=vt[1][j];
			vt[nx+1][j]=-vt[nx][j];
			p[0][j]=p[1][j];
			p[nx+1][j]=p[nx][j];
		}

// 		-------------------------Predicted Velocities and mass source term-------------------------------
	for(i=1;i<=nx;i++)
		{
		for(j=1;j<=ny;j++)
			{

				utw=(ut[i][j]+ut[i-1][j])/2.0;
				ute=(ut[i+1][j]+ut[i][j])/2.0;
				vtn=(vt[i][j]+vt[i][j+1])/2.0;
				vts=(vt[i][j]+vt[i][j-1])/2.0;

				//face density
				frho();
		//		printf("e=%f  w=%f  n=%f  s=%f\n",rhoe,rhow,rhon,rhos);
				uwp=utw-(dt/(dx*rhow))*(p[i][j]-p[i-1][j]);
				uep=ute-(dt/(dx*rhoe))*(p[i+1][j]-p[i][j]);
				vsp=vts-(dt/(dy*rhos))*(p[i][j]-p[i][j-1]);
				vnp=vtn-(dt/(dy*rhon))*(p[i][j+1]-p[i][j]);

				s[i][j]=uwp*dy-uep*dy-vnp*dx+vsp*dx;
		//		printf("i=%d  j=%d  Source=%f\n",i,j,s[i][j]);
			}
		}
// 		-------------------------------------Pressure Correction calculations--------------------------------------
int gcount=0;
do
{
gsum=0.0;

	//Boundary conditions for pressure corrections
	for(i=1;i<=nx;i++)
		{
			pc[i][ny+1]=pc[i][ny];
			pc[i][0]=pc[i][1];
		}
	for(j=1;j<=ny;j++)
		{
			pc[0][j]=pc[1][j];
			pc[nx+1][j]=pc[nx][j];
		}

	for(i=1;i<=nx;i++)
		{
		for(j=1;j<=ny;j++)
			{
				double apg;
				//Face density
				frho();
				apg=(dt*dy/(rhoe*dx))+(dt*dy/(rhow*dx))+(dx*dt/(rhon*dy))+(dt*dx/(rhos*dy));
				Res=s[i][j]+(dt*dy/dx)*((pc[i+1][j]/rhoe)+(pc[i-1][j]/rhow))+(dt*dx/dy)*((pc[i][j+1]/rhon)+(pc[i][j-1]/rhos))-apg*pc[i][j];
				corr=Res/(rel_fac*apg);
				pc[i][j]=pc[i][j]+corr;
				gsqr=Res*Res;
				gsum=gsum+gsqr;

			}
		}
				gRMS=sqrt(gsum/(nx*ny));
				if(gcount%1000==0)
				printf("\tPressure correction-->> gRMS=%.10f\t\tgcount=%d\n",gRMS,gcount);
gcount++;
if(gRMS<0.000001)
	gcount=0;
}while(gRMS>0.000001);
//		-------------------------------------Calculation of new pressure------------------------------------
for(i=1;i<=nx;i++)
		{
		for(j=1;j<=ny;j++)
			{
				pnew[i][j]=p[i][j]+pc[i][j];
				pc[i][j]=0.0;
			}
		}
//		----------------------Boundary conditions for new pressure and velocity correction-----------------
	for(i=1;i<=nx;i++)
		{
			pnew[i][ny+1]=pnew[i][ny];
			pnew[i][0]=pnew[i][1];
			uc[i][0]=-uc[i][1];
			uc[i][ny+1]=-uc[i][ny];
			vc[i][0]=-vc[i][1];
			vc[i][ny+1]=-vc[i][ny];
		}
	for(j=1;j<=ny;j++)
		{
			pnew[0][j]=pnew[1][j];
			pnew[nx+1][j]=pnew[nx][j];
			uc[0][j]=-uc[1][j];	// As u at symmetry is zero the correction too becomes zero as u is known
			uc[nx+1][j]=-uc[nx][j]; // As u at symmetry is zero the correction too becomes zero as u is known
			vc[0][j]=vc[1][j];
			vc[nx+1][j]=vc[nx][j];
		}

//		---------------------------------------calculation of new velocity----------------------------------
for(i=1;i<=nx;i++)
		{
		for(j=1;j<=ny;j++)
			{
				//Face density
				frho();

				uc[i][j]=0.5*(dt/dx)*((pnew[i+1][j]/rhoe)-(pnew[i-1][j]/rhow)+pnew[i][j]*(1.0/rhow-1.0/rhoe));
				vc[i][j]=0.5*(dt/dy)*((pnew[i][j+1]/rhon)-(pnew[i][j-1]/rhos)+pnew[i][j]*(1.0/rhos-1.0/rhon));
				unew[i][j]=ut[i][j]-uc[i][j];
				vnew[i][j]=vt[i][j]-vc[i][j];
				//RMS for steady state
				diff=unew[i][j]-u[i][j];
				sqr=diff*diff;
				sum=sum+sqr;

				//Updating the old values
				u[i][j]=unew[i][j];
				v[i][j]=vnew[i][j];
				p[i][j]=pnew[i][j];
			//	printf("i=%d  j=%d  uc=%f\tvc=%f\tp=%f\n",i,j,uc[i][j],vc[i][j],pnew[i][j]);
				
				double co[1000][1000]; 
				co[i][j]=(u[i][j]*dt/dx)+(v[i][j]*dt/dy);
				if(co[i][j]>0.5)
				printf("courant at %d %d exceeds 0.5 as %f",i,j,co[i][j]);			
			}
		}

RMS=sqrt(sum/(nx*ny));
tc=tc+1;
time=tc*dt;
fclose(f2);
fclose(f3);
printf("------------------------------------VOF-------------------------------------\n");
printf("\nMass Loss(percent)=  %.10f \t Time= %f \t Reconstruction happens %d times\n",fabs(sumx-sumy)*100,time,rcnst_count);
printf("------------------------------------N-S-------------------------------------\n");
printf("u-vel=%f\tv-vel=%f\tp=%f\tuRMS=%f\n",u[nx/2][ny/2],v[nx/2][ny/2],p[nx/2][ny/2],RMS);
}while(time<dt);
//		-------------------------------------------File Writing-----------------------------------------//

FILE *f1;
f1=fopen("Plic_grid1.dat","w");
//fprintf(f1,"\nVARIABLES=""X"",""Y"", \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx+1,ny+1);
for(i=1;i<=nx+1;i++)
	{
	for(j=1;j<=ny+1;j++)
		{
			fprintf(f1,"\t%f\t%f\n",xp[i],yp[j]);

		}
		fprintf(f1,"\n");
	}
fclose(f1);

f1=fopen("Plic_grid2.dat","w");
//fprintf(f1,"\nVARIABLES=""X"",""Y"", \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx+1,ny+1);
for(j=1;j<=ny+1;j++)
	{
	for(i=1;i<=nx+1;i++)
		{
			fprintf(f1,"\t%f\t%f\n",xp[i],yp[j]);
		}
		fprintf(f1,"\n");
	}
fclose(f1);
/*
FILE *f3;
f3=fopen("Patch.dat","w");
//fprintf(f3,"\nVARIABLES=""X"",""Y"",""phi"",""u-vel"",""v-vel"" \nZONE I=%d,J=%d,ZONETYPE=ORDERED,DATAPACKING=POINT\n",nx,ny);
for(i=1;i<=nx;i++)
	{
	for(j=1;j<=ny;j++)
		{
			fprintf(f3,"\t%f\t%f\t%f\t%f\t%f\n",x[i],y[j],phi[i][j],u[i][j],v[i][j]);

		}
	//	fprintf(f1,"\n");
	}
fclose(f3);
*/
}
